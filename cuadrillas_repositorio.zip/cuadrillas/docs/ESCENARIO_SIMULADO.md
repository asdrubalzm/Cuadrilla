# Escenario simulado de validación

Todo lo que sigue es ficticio. Se diseñó para que el prototipo pueda probarse de principio a fin
en un entorno controlado, sin datos de ninguna empresa.

## Edificio

- **Nombre:** Torre Hudson (simulada), edificio de oficinas de 22 pisos y 2 subsuelos.
- **Servicio:** limpieza de vidrios interiores (vestíbulo, puertas, mamparas, atrio, pasamanos).
- **Ubicación de referencia:** un punto genérico de Midtown Manhattan, Nueva York (40.7540, -73.9840).
- **Radio de validación de evidencias:** 150 m.

## Acuerdo de nivel de servicio

| Frecuencia | Zonas | Hora límite (Nueva York) | Tolerancia |
|---|---|---|---|
| Diaria | Vidrios a nivel de piso y subsuelos | 11:00 | 15 min |
| Semanal | Paños altos (trabajo sobre escalera) | 16:00 | 30 min |

## Cuadrilla

Un supervisor (Carlos Rivas), tres operarios (Ana Torres, Luis Peña y Marta Solís) y una
gerente de operaciones (Laura Méndez).

## Zonas (18; 1 305 m² de vidrio)

| Zona | Piso | Tipo | m² | Trabajo en altura |
|---|---|---|---|---|
| Vestíbulo principal | 1 | Interior | 120 | No |
| Puertas giratorias y acceso | 1 | Interior | 45 | No |
| Vestíbulo, paños altos | 1 | Interior | 90 | Sí (escalera) |
| Pasamanos de vidrio, escalera principal | 2 | Interior | 55 | No |
| Mamparas piso 5 | 5 | Interior | 85 | No |
| Mamparas piso 8 | 8 | Interior | 85 | No |
| Mamparas piso 10 | 10 | Interior | 85 | No |
| Salas de reuniones piso 12 | 12 | Interior | 60 | No |
| Atrio piso 15 | 15 | Interior | 140 | No |
| Atrio piso 15, paños altos | 15 | Interior | 110 | Sí (escalera) |
| Mamparas piso 17 | 17 | Interior | 85 | No |
| Mamparas piso 20 | 20 | Interior | 85 | No |
| Comedor piso 22 | 22 | Interior | 70 | No |
| Comedor piso 22, ventanales altos | 22 | Interior | 60 | Sí (escalera) |
| Subsuelo 1, acceso vehicular | -1 | Subsuelo | 40 | No |
| Subsuelo 1, garita y oficinas | -1 | Subsuelo | 35 | No |
| Subsuelo 2, ascensores | -2 | Subsuelo | 30 | No |
| Subsuelo 2, cuarto de control | -2 | Subsuelo | 25 | No |

Los subsuelos representan los puntos sin cobertura de datos; en las pruebas se reproducen
activando el modo avión del teléfono. En las tres zonas con paños altos la aplicación añade a
la lista de seguridad los ítems de la escalera.

## Insumos

| Insumo | Rendimiento | Existencia inicial | Mínimo | Costo simulado |
|---|---|---|---|---|
| Limpiavidrios diluido | 15 ml/m² | 40 000 ml | 8 000 ml | USD 0,0040 por ml |
| Desengrasante neutro | 8 ml/m² | 20 000 ml | 4 000 ml | USD 0,0060 por ml |

Tolerancia de consumo (RN4): 15 % sobre el teórico.

## Jornada de prueba

Un sprint de dos semanas que empieza el lunes de la semana en que se carga la base y
18 órdenes planificadas para el día de la carga, todas sin asignar.
