# Guía de pruebas y hoja de resultados

Ejecute las pruebas con la base recién creada (`docker compose down -v && docker compose up --build`).
Anote cada resultado en la hoja del final y guarde una captura o el texto de la terminal como
respaldo. Los resultados que se trasladen al documento deben ser los que usted obtenga.

## A. Pruebas automáticas (10 minutos)

| Comando (en `cuadrillas-api/`) | Qué demuestra | Qué guardar |
|---|---|---|
| `npm test` | 32 pruebas unitarias: transiciones, lista de seguridad, consumo, SLA, geocerca, huella | Salida con `# pass 32` y `# fail 0` |
| `docker compose exec -T db psql -U cuadrillas -d cuadrillas -v ON_ERROR_STOP=1 < test/esquema.sql` | 10 reglas de la base (idempotencia, existencias, RN5…) | Las diez líneas `OK` |
| `npm run test:flujo` | CP01, CP02, CP03, CP06, CP08, CP10, CP11 y CP12 a nivel de API | Las líneas `CUMPLE` |
| `cd ../cuadrillas-app && flutter test` | Pruebas unitarias del cliente | Salida `All tests passed!` |

Después de `test:flujo`, reinicie la base antes de continuar.

## B. Pruebas de aceptación en el teléfono (60 a 90 minutos)

Preparación: panel web abierto como `supervisor@demo.local`; teléfono con la aplicación abierta
como `ana@demo.local`. En el panel, asigne a Ana tres órdenes: **Vestíbulo principal**,
**Subsuelo 2, ascensores** y **Vestíbulo, paños altos**.

| Caso | Pasos | Resultado esperado |
|---|---|---|
| CP03 | Abra «Vestíbulo, paños altos». Marque todos los ítems menos «Escalera inspeccionada, sin defectos visibles». | El botón «Iniciar rutina» sigue deshabilitado. Al marcar el último, se habilita. |
| CP04 | Deslice para actualizar la lista. Active el **modo avión**. Abra «Subsuelo 2, ascensores», complete la lista, inicie, tome la fotografía y finalice. | La orden queda «Finalizada» en el teléfono y el aviso indica registros por enviar. En el panel sigue «ASIGNADA». |
| CP07 | Sin quitar el modo avión, cierre la aplicación desde el gestor de tareas y vuelva a abrirla. | La orden sigue finalizada y el aviso de pendientes continúa. |
| CP05 | Desactive el modo avión y cronometre. | En menos de un minuto el aviso desaparece y en el panel la orden pasa a «Revisión» con su fotografía. |
| CP08 | Complete «Vestíbulo principal» (120 m²) dejando 1 800 ml de limpiavidrios. En el panel, pestaña Tablero, compare las existencias antes y después. | Consumo esperado 1 800 ml; las existencias bajan 1 800 ml. |
| CP09 | Asigne otra orden interior y finalícela registrando un consumo 20 % mayor que el esperado. | En la terminal de la API aparece el aviso «consumo sobre la tolerancia». |
| CP11 | Finalice una orden estando fuera del radio de 150 m del punto del edificio (o con la ubicación del emulador puesta en otra ciudad). | En la revisión, la evidencia aparece como «FUERA DEL RADIO DEL EDIFICIO». |
| CP12 | En el panel, rechace una orden en revisión con un comentario. Actualice la lista en el teléfono. | La orden vuelve al teléfono «En ejecución». |
| CP13 | Con una orden asignada y abierta, ejecute en la base: `UPDATE orden_trabajo SET fin_plan = now() + interval '20 minutes' WHERE id = '<id>';` y espere hasta 5 minutos. | En la terminal de la API aparece «por vencer» una sola vez y el tablero la lista en riesgo. |
| CP14 | `npm run test:carga` (50 usuarios, 5 minutos). | `p95Ms` ≤ 2000 y `errores` = 0. |
| CP15 | Cuente las pantallas entre la lista de órdenes y el cierre de una rutina. | Tres: lista, seguridad y ejecución. |

CP01, CP02, CP06 y CP10 quedan cubiertos por `npm run test:flujo`; puede repetirlos a mano con
Postman si desea capturas.

Para ejecutar SQL en la base: `docker compose exec db psql -U cuadrillas -d cuadrillas`.

## C. Medición comparativa en entorno controlado (45 minutos)

Compara el procedimiento manual con registro escrito (hoja de cálculo y mensajes) con el sistema,
usando el mismo escenario: 18 órdenes y 3 operarios. El comparador es el procedimiento manual que
deja el mismo registro que el sistema; una instrucción verbal es más rápida, pero no deja constancia. Use un cronómetro. Repita cada tarea tres veces y promedie.

**Reparto que debe lograrse en ambas modalidades:** seis órdenes por operario, con las tres
zonas de paños altos repartidas una por persona.

| Tarea | Procedimiento manual | Con el sistema |
|---|---|---|
| T1. Asignar la jornada | Copie la tabla de zonas de `ESCENARIO_SIMULADO.md` a una hoja de cálculo, escriba el operario de cada fila y redacte un mensaje por operario con sus seis zonas, su superficie y su hora límite (sin enviarlo). | En el panel, pestaña «Sprint y asignación», elija el operario de cada una de las 18 órdenes. |
| T2. Reasignar por ausencia | Un operario falta: reparta sus seis zonas entre los otros dos en la hoja y redacte los dos mensajes de aviso. | Cambie el operario de esas seis órdenes en el panel. |
| T3. Informe de la jornada | Con cinco órdenes terminadas, calcule en la hoja el consumo esperado de limpiavidrios por orden (m² × 15) y cuántas terminaron antes de su hora límite. | Abra la pestaña «Tablero» y lea consumo y cumplimiento. |

Reducción (%) = (tiempo manual − tiempo con el sistema) ÷ tiempo manual × 100.

**Órdenes con evidencia verificable:** de las órdenes que ejecute en las pruebas B, cuente las que
tienen fotografía recibida, ubicación y hora. El dato exacto aparece en el Tablero
(«Órdenes con evidencia verificable») o en `GET /reportes/sla`.

## D. Hoja de resultados

Fecha: ________  Equipo: ________________  Teléfono y versión de Android: ________________

### Pruebas automáticas

| Prueba | Resultado obtenido |
|---|---|
| Unitarias del dominio (`npm test`) | ____ de 32 |
| Reglas de la base (`test/esquema.sql`) | ____ de 10 |
| Recorrido de la API (`test:flujo`) | ____ de ____ |
| Unitarias del cliente (`flutter test`) | ____ de ____ |

### Casos de prueba

| Caso | Resultado obtenido | Cumple (sí/no) | Evidencia (archivo) |
|---|---|---|---|
| CP01 | | | |
| CP02 | | | |
| CP03 | | | |
| CP04 | | | |
| CP05 | Tiempo hasta vaciar la cola: ____ s | | |
| CP06 | | | |
| CP07 | | | |
| CP08 | | | |
| CP09 | | | |
| CP10 | | | |
| CP11 | | | |
| CP12 | | | |
| CP13 | | | |
| CP14 | p95 = ____ ms; errores = ____ | | |
| CP15 | ____ pantallas | | |

### Medición comparativa (minutos:segundos)

| Tarea | Manual 1 | Manual 2 | Manual 3 | Promedio manual | Sistema 1 | Sistema 2 | Sistema 3 | Promedio sistema | Reducción % |
|---|---|---|---|---|---|---|---|---|---|
| T1. Asignar la jornada | | | | | | | | | |
| T2. Reasignar por ausencia | | | | | | | | | |
| T3. Informe de la jornada | | | | | | | | | |

Órdenes ejecutadas en las pruebas: ____  Con evidencia verificable: ____ (____ %)
Órdenes ejecutadas sin conexión: ____  Sincronizadas sin pérdida ni duplicado: ____ (____ %)
