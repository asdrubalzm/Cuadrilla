// Recorrido automático de la API con el escenario simulado. No usa dependencias.
// Cubre a nivel de servidor los casos CP01, CP02, CP03, CP06, CP08, CP10, CP11 y CP12.
//
// Uso (con la API en marcha y la base recién creada):
//   node test/flujo_api.mjs [urlBase]
// Modifica datos: para repetirlo, reinicie la base con  docker compose down -v && docker compose up
import { createHash, randomUUID } from 'node:crypto';

const base = process.argv[2] ?? 'http://localhost:3000';
const resultados = [];
const anotar = (caso, descripcion, ok, detalle = '') => {
  resultados.push({ caso, ok });
  console.log(`${ok ? 'CUMPLE   ' : 'NO CUMPLE'}  ${caso}  ${descripcion}${detalle ? `  [${detalle}]` : ''}`);
};

async function api(metodo, ruta, { token, cuerpo, formulario } = {}) {
  const cabeceras = { 'x-dispositivo': 'script-de-pruebas' };
  if (token) cabeceras.authorization = `Bearer ${token}`;
  if (cuerpo) cabeceras['content-type'] = 'application/json';
  const r = await fetch(base + ruta, {
    method: metodo, headers: cabeceras,
    body: formulario ?? (cuerpo ? JSON.stringify(cuerpo) : undefined),
  });
  let datos = null;
  try { datos = await r.json(); } catch { /* respuesta sin cuerpo */ }
  return { codigo: r.status, datos };
}
const login = (email, clave = 'Demo2026*') => api('POST', '/auth/login', { cuerpo: { email, clave } });
const lote = (token, operaciones) => api('POST', '/sync/lote', { token, cuerpo: { operaciones } });
const estados = (r) => (r.datos?.resultados ?? []).map((x) => x.estado).join(',');

// ---------------------------------------------------------------- CP01
const sup = await login('supervisor@demo.local');
const ana = await login('ana@demo.local');
const malo = await login('ana@demo.local', 'clave-incorrecta');
anotar('CP01', 'Inicio de sesión válido entrega token; inválido responde 401',
  sup.codigo === 200 && !!sup.datos?.token && ana.codigo === 200 && malo.codigo === 401,
  `${sup.codigo}/${ana.codigo}/${malo.codigo}`);
if (!sup.datos?.token || !ana.datos?.token) {
  console.log('No se pudo iniciar sesión: revise que la API esté en marcha y la base tenga el escenario.');
  process.exit(1);
}
const S = sup.datos.token, A = ana.datos.token, anaId = ana.datos.usuario.id;

// ---------------------------------------------------------------- preparación
const sprints = await api('GET', '/sprints', { token: S });
const sprintId = sprints.datos[0].id;
const ordenes = (await api('GET', `/ordenes?sprintId=${sprintId}`, { token: S })).datos;
const vestibulo = ordenes.find((o) => o.zonaNombre === 'Vestíbulo principal');
if (!vestibulo || vestibulo.estado !== 'PLANIFICADA') {
  console.log('La orden del vestíbulo ya fue usada. Reinicie la base antes de repetir el recorrido.');
  process.exit(1);
}

// ---------------------------------------------------------------- CP02
const ajena = await api('POST', `/ordenes/${vestibulo.id}/asignar`, { token: A, cuerpo: { operarioId: anaId } });
anotar('CP02', 'Un operario no puede asignar órdenes (403)', ajena.codigo === 403, String(ajena.codigo));

const asignada = await api('POST', `/ordenes/${vestibulo.id}/asignar`, { token: S, cuerpo: { operarioId: anaId } });
const mias = await api('GET', '/ordenes/mias', { token: A });
const insumo = mias.datos.insumos.find((i) => i.nombre === 'Limpiavidrios diluido');
anotar('RF06', 'El supervisor asigna y la orden aparece en la lista del operario',
  asignada.codigo === 200 && mias.datos.ordenes.some((o) => o.id === vestibulo.id));

const existencias = async () =>
  (await api('GET', '/inventario/insumos', { token: S })).datos.find((i) => i.id === insumo.id).stockActual;
const stockInicial = await existencias();

// ---------------------------------------------------------------- CP03 (regla en el servidor)
const incompleta = await lote(A, [{
  operacionUuid: randomUUID(), entidad: 'orden', accion: 'INICIAR',
  payload: { ordenId: vestibulo.id, inicioReal: new Date().toISOString(), checklist: { gafas: true, guantes: false } },
}]);
anotar('CP03', 'El servidor rechaza un inicio con la lista de seguridad incompleta',
  estados(incompleta) === 'RECHAZADA', estados(incompleta));

// ---------------------------------------------------------------- ciclo completo en un lote
const foto = Buffer.from(`fotografia-de-prueba-${randomUUID()}`);
const huella = createHash('sha256').update(foto).digest('hex');
const evidenciaId = randomUUID();
const operaciones = [
  { operacionUuid: randomUUID(), entidad: 'orden', accion: 'INICIAR',
    payload: { ordenId: vestibulo.id, inicioReal: new Date(Date.now() - 40 * 60000).toISOString(),
      checklist: { 'Guantes y gafas de seguridad': true, 'Químico y paños suficientes para la zona': true, 'Señal de piso mojado colocada': true } } },
  { operacionUuid: randomUUID(), entidad: 'orden', accion: 'FINALIZAR',
    payload: { ordenId: vestibulo.id, finReal: new Date().toISOString(),
      evidencia: { id: evidenciaId, tipo: 'DESPUES', hashSha256: huella, latitud: 40.7541, longitud: -73.9841, precisionM: 12, capturadoEn: new Date().toISOString() },
      consumoReal: { [insumo.id]: 1800 } } },
];
const primero = await lote(A, operaciones);
anotar('RF12', 'Un lote con inicio y cierre se aplica en orden', estados(primero) === 'APLICADA,APLICADA', estados(primero));

// ---------------------------------------------------------------- CP06 y CP08
const segundo = await lote(A, operaciones);
const tercero = await lote(A, operaciones);
let detalle = (await api('GET', `/ordenes/${vestibulo.id}`, { token: S })).datos;
const stockTrasCierre = await existencias();
anotar('CP06', 'El mismo lote enviado tres veces produce un solo consumo y un solo descuento',
  estados(segundo) === 'DUPLICADA,DUPLICADA' && estados(tercero) === 'DUPLICADA,DUPLICADA' &&
  detalle.consumos.length === 1 && stockInicial - stockTrasCierre === 1800,
  `consumos=${detalle.consumos.length}, descuento=${stockInicial - stockTrasCierre}`);
anotar('CP08', '120 m² con 15 ml/m²: consumo teórico de 1 800 ml y existencias reducidas en lo real',
  detalle.consumos[0]?.teorica === 1800 && detalle.consumos[0]?.real === 1800 && detalle.estado === 'EN_REVISION',
  `teórico=${detalle.consumos[0]?.teorica}, estado=${detalle.estado}`);

// ---------------------------------------------------------------- CP10
const subir = (contenido) => {
  const f = new FormData();
  f.append('evidenciaId', evidenciaId);
  f.append('archivo', new Blob([contenido], { type: 'image/jpeg' }), 'foto.jpg');
  return api('POST', '/evidencias', { token: A, formulario: f });
};
const alterada = await subir(Buffer.from('contenido-alterado'));
const correcta = await subir(foto);
anotar('CP10', 'Un archivo que no coincide con la huella se rechaza (422); el original se acepta',
  alterada.codigo === 422 && correcta.codigo === 201 && correcta.datos?.estado === 'RECIBIDA',
  `${alterada.codigo}/${correcta.codigo}`);

// ---------------------------------------------------------------- CP12
const sinComentario = await api('POST', `/ordenes/${vestibulo.id}/evaluacion`, { token: S, cuerpo: { conforme: false, puntaje: 2 } });
const rechazo = await api('POST', `/ordenes/${vestibulo.id}/evaluacion`,
  { token: S, cuerpo: { conforme: false, puntaje: 2, comentario: 'Quedaron marcas en el paño inferior.' } });
const trasRechazo = (await api('GET', '/ordenes/mias', { token: A })).datos.ordenes.find((o) => o.id === vestibulo.id);
anotar('CP12', 'El rechazo exige comentario y devuelve la orden a ejecución en la lista del operario',
  sinComentario.codigo === 400 && rechazo.codigo === 200 && trasRechazo?.estado === 'EN_EJECUCION',
  `${sinComentario.codigo}/${rechazo.codigo}/${trasRechazo?.estado}`);

// ---------------------------------------------------------------- CP09 y CP11 (reproceso)
const reproceso = await lote(A, [{
  operacionUuid: randomUUID(), entidad: 'orden', accion: 'FINALIZAR',
  payload: { ordenId: vestibulo.id, finReal: new Date().toISOString(),
    evidencia: { id: randomUUID(), tipo: 'DESPUES', hashSha256: huella, latitud: 40.7630, longitud: -73.9840, precisionM: 10, capturadoEn: new Date().toISOString() },
    consumoReal: { [insumo.id]: 2100 } },   // supera 1 800 ml × 1,15 = 2 070 ml
}]);
detalle = (await api('GET', `/ordenes/${vestibulo.id}`, { token: S })).datos;
const lejana = detalle.evidencias.find((e) => e.latitud === 40.763);
anotar('CP11', 'Una evidencia capturada a 1 km se acepta y queda marcada fuera del radio',
  estados(reproceso) === 'APLICADA' && lejana?.fueraDeGeocerca === true, `fueraDeGeocerca=${lejana?.fueraDeGeocerca}`);
console.log('           CP09  Revise el registro del servidor: debe aparecer el aviso');
console.log('                 "consumo sobre la tolerancia" para el reproceso de 2 100 ml.');

// ---------------------------------------------------------------- aprobación y estado final
const aprobacion = await api('POST', `/ordenes/${vestibulo.id}/evaluacion`, { token: S, cuerpo: { conforme: true, puntaje: 5 } });
const repetida = await api('POST', `/ordenes/${vestibulo.id}/evaluacion`, { token: S, cuerpo: { conforme: true, puntaje: 5 } });
anotar('RF16', 'La orden aprobada es un estado final (un segundo intento responde 409)',
  aprobacion.codigo === 200 && repetida.codigo === 409, `${aprobacion.codigo}/${repetida.codigo}`);

const cumplen = resultados.filter((r) => r.ok).length;
console.log(`\n${cumplen} de ${resultados.length} comprobaciones cumplen.`);
process.exit(cumplen === resultados.length ? 0 : 1);
