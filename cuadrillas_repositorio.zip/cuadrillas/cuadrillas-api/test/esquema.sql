-- Pruebas de las reglas que la base de datos hace cumplir por sí misma.
-- Uso:  psql -v ON_ERROR_STOP=1 -d cuadrillas -f test/esquema.sql
-- Todo ocurre dentro de una transacción que se revierte: no deja datos.
BEGIN;

DO $$
DECLARE
  v_usuario uuid; v_orden uuid; v_insumo uuid; v_op uuid := gen_random_uuid(); n int;
BEGIN
  SELECT id INTO v_usuario FROM usuario WHERE rol = 'OPERARIO' LIMIT 1;
  SELECT id INTO v_orden FROM orden_trabajo LIMIT 1;
  SELECT id INTO v_insumo FROM insumo LIMIT 1;

  -- 1. Idempotencia: el mismo identificador de operación no entra dos veces (RN6)
  INSERT INTO sync_operacion VALUES (v_op, v_usuario, 'telefono-prueba', 'orden', 'FINALIZAR', 'APLICADA');
  BEGIN
    INSERT INTO sync_operacion VALUES (v_op, v_usuario, 'telefono-prueba', 'orden', 'FINALIZAR', 'APLICADA');
    RAISE EXCEPTION 'FALLA 1: se aceptó una operación repetida';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'OK 1: operación repetida rechazada (23505)';
  END;

  -- 2. Las existencias no pueden quedar negativas
  BEGIN
    UPDATE insumo SET stock_actual = -1 WHERE id = v_insumo;
    RAISE EXCEPTION 'FALLA 2: existencias negativas aceptadas';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK 2: existencias negativas rechazadas';
  END;

  -- 3. No hay hora de fin real sin hora de inicio real
  BEGIN
    UPDATE orden_trabajo SET fin_real = now() WHERE id = v_orden;
    RAISE EXCEPTION 'FALLA 3: fin real sin inicio real';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK 3: fin sin inicio rechazado';
  END;

  -- 4. El fin planificado debe ser posterior al inicio planificado
  BEGIN
    UPDATE orden_trabajo SET fin_plan = inicio_plan - interval '1 minute' WHERE id = v_orden;
    RAISE EXCEPTION 'FALLA 4: plan con fin anterior al inicio';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK 4: plan incoherente rechazado';
  END;

  -- 5. La prioridad solo admite 1, 2 o 3
  BEGIN
    UPDATE orden_trabajo SET prioridad = 4 WHERE id = v_orden;
    RAISE EXCEPTION 'FALLA 5: prioridad fuera de rango';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK 5: prioridad fuera de rango rechazada';
  END;

  -- 6. Un estado que no existe en el diagrama no se puede guardar
  BEGIN
    EXECUTE format('UPDATE orden_trabajo SET estado = %L WHERE id = %L', 'TERMINADA', v_orden);
    RAISE EXCEPTION 'FALLA 6: estado inexistente aceptado';
  EXCEPTION WHEN invalid_text_representation THEN RAISE NOTICE 'OK 6: estado inexistente rechazado';
  END;

  -- 7. RN5: un rechazo sin comentario no se guarda
  BEGIN
    INSERT INTO evaluacion_calidad (orden_id, supervisor_id, resultado, puntaje, comentario)
    SELECT v_orden, id, 'NO_CONFORME', 2, '  ' FROM usuario WHERE rol = 'SUPERVISOR' LIMIT 1;
    RAISE EXCEPTION 'FALLA 7: rechazo sin comentario aceptado';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'OK 7: rechazo sin comentario rechazado';
  END;

  -- 8. Una evidencia debe pertenecer a una orden que exista
  BEGIN
    INSERT INTO evidencia (id, orden_id, tipo, hash_sha256, capturado_en)
    VALUES (gen_random_uuid(), gen_random_uuid(), 'DESPUES', repeat('a', 64), now());
    RAISE EXCEPTION 'FALLA 8: evidencia huérfana aceptada';
  EXCEPTION WHEN foreign_key_violation THEN RAISE NOTICE 'OK 8: evidencia sin orden rechazada';
  END;

  -- 9. El escenario simulado está completo: 18 órdenes planificadas y sin asignar
  SELECT count(*) INTO n FROM orden_trabajo WHERE estado = 'PLANIFICADA' AND operario_id IS NULL;
  IF n <> 18 THEN RAISE EXCEPTION 'FALLA 9: se esperaban 18 órdenes y hay %', n; END IF;
  RAISE NOTICE 'OK 9: 18 órdenes planificadas en el escenario';

  -- 10. CP08: 120 m² × 15 ml/m² = 1 800 ml con los datos del escenario
  SELECT (z.superficie_m2 * i.rendimiento_ml_m2)::int INTO n
  FROM zona z, insumo i WHERE z.nombre = 'Vestíbulo principal' AND i.nombre = 'Limpiavidrios diluido';
  IF n <> 1800 THEN RAISE EXCEPTION 'FALLA 10: consumo teórico %', n; END IF;
  RAISE NOTICE 'OK 10: consumo teórico del vestíbulo = 1800 ml';
END $$;

ROLLBACK;
