// Prueba de carga sin dependencias (caso CP14): usuarios simulados que consultan sus órdenes.
// Uso:  node test/carga.mjs [urlBase] [usuarios] [segundos]
// Ejemplo:  node test/carga.mjs http://localhost:3000 50 300
const [base = 'http://localhost:3000', usuariosArg = '50', segundosArg = '300'] = process.argv.slice(2);
const USUARIOS = Number(usuariosArg);
const DURACION_MS = Number(segundosArg) * 1000;
const CUENTAS = ['ana', 'luis', 'marta'].map((n) => `${n}@demo.local`);

async function login(email) {
  const r = await fetch(`${base}/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, clave: 'Demo2026*' }),
  });
  if (!r.ok) throw new Error(`Inicio de sesión fallido (${r.status}) para ${email}`);
  return (await r.json()).token;
}

const tiempos = [];
let errores = 0;

async function usuario(token, hasta) {
  while (Date.now() < hasta) {
    const t0 = performance.now();
    try {
      const r = await fetch(`${base}/ordenes/mias`, { headers: { authorization: `Bearer ${token}` } });
      await r.arrayBuffer();
      if (!r.ok) errores++;
    } catch {
      errores++;
    }
    tiempos.push(performance.now() - t0);
    await new Promise((ok) => setTimeout(ok, 500 + Math.random() * 500)); // pausa entre consultas
  }
}

const tokens = await Promise.all(CUENTAS.map(login));
const hasta = Date.now() + DURACION_MS;
console.log(`${USUARIOS} usuarios simulados durante ${DURACION_MS / 1000} s contra ${base} ...`);
await Promise.all(Array.from({ length: USUARIOS }, (_, i) => usuario(tokens[i % tokens.length], hasta)));

tiempos.sort((a, b) => a - b);
const pct = (p) => tiempos[Math.min(tiempos.length - 1, Math.floor((p / 100) * tiempos.length))];
console.log(JSON.stringify({
  peticiones: tiempos.length,
  errores,
  mediaMs: Math.round(tiempos.reduce((a, b) => a + b, 0) / tiempos.length),
  p50Ms: Math.round(pct(50)),
  p95Ms: Math.round(pct(95)),
  maxMs: Math.round(tiempos[tiempos.length - 1]),
}, null, 2));
console.log(pct(95) <= 2000 && errores === 0 ? 'CP14: CUMPLE (p95 <= 2 s y sin errores)' : 'CP14: NO CUMPLE');
