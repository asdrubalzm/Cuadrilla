// Pruebas unitarias del dominio. Se ejecutan con:  npm test
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import { EstadoOrden, TRANSICIONES, puedeTransitar, checklistAprobado, ESTADOS_ABIERTOS } from '../src/dominio/estados';
import { consumoTeorico, excedeTolerancia, redondear, TOLERANCIA_CONSUMO } from '../src/dominio/consumo';
import { nivelAlerta, cumpleSla } from '../src/dominio/sla';
import { distanciaMetros, fueraDeGeocerca } from '../src/dominio/geocerca';
import { hashClave, verificarClave } from '../src/dominio/clave';
import { sha256Hex, huellaCoincide } from '../src/dominio/huella';

describe('Tabla de transiciones de la orden', () => {
  test('todos los estados tienen una entrada en la tabla', () => {
    for (const e of Object.values(EstadoOrden)) assert.ok(Array.isArray(TRANSICIONES[e]), e);
  });

  test('recorrido normal: de planificada a aprobada', () => {
    const camino = [
      EstadoOrden.PLANIFICADA, EstadoOrden.ASIGNADA, EstadoOrden.EN_PREPARACION,
      EstadoOrden.EN_EJECUCION, EstadoOrden.FINALIZADA, EstadoOrden.EN_REVISION, EstadoOrden.APROBADA,
    ];
    for (let i = 0; i < camino.length - 1; i++) {
      assert.ok(puedeTransitar(camino[i], camino[i + 1]), `${camino[i]} -> ${camino[i + 1]}`);
    }
  });

  test('no se puede saltar la lista de seguridad (asignada -> en ejecución)', () => {
    assert.equal(puedeTransitar(EstadoOrden.ASIGNADA, EstadoOrden.EN_EJECUCION), false);
  });

  test('no se puede aprobar una orden que no pasó por revisión', () => {
    assert.equal(puedeTransitar(EstadoOrden.EN_EJECUCION, EstadoOrden.APROBADA), false);
    assert.equal(puedeTransitar(EstadoOrden.FINALIZADA, EstadoOrden.APROBADA), false);
  });

  test('el rechazo devuelve la orden a ejecución (reproceso)', () => {
    assert.ok(puedeTransitar(EstadoOrden.EN_REVISION, EstadoOrden.RECHAZADA));
    assert.deepEqual(TRANSICIONES[EstadoOrden.RECHAZADA], [EstadoOrden.EN_EJECUCION]);
  });

  test('una orden bloqueada se retoma o se reasigna', () => {
    assert.ok(puedeTransitar(EstadoOrden.EN_PREPARACION, EstadoOrden.BLOQUEADA));
    assert.ok(puedeTransitar(EstadoOrden.EN_EJECUCION, EstadoOrden.BLOQUEADA));
    assert.ok(puedeTransitar(EstadoOrden.BLOQUEADA, EstadoOrden.EN_EJECUCION));
    assert.ok(puedeTransitar(EstadoOrden.BLOQUEADA, EstadoOrden.ASIGNADA));
  });

  test('aprobada y cancelada son estados finales', () => {
    assert.deepEqual(TRANSICIONES[EstadoOrden.APROBADA], []);
    assert.deepEqual(TRANSICIONES[EstadoOrden.CANCELADA], []);
  });

  test('solo se cancela antes de empezar', () => {
    const cancelables = Object.values(EstadoOrden).filter((e) => puedeTransitar(e, EstadoOrden.CANCELADA));
    assert.deepEqual(cancelables, [EstadoOrden.PLANIFICADA, EstadoOrden.ASIGNADA]);
  });

  test('los estados abiertos son los cuatro que vigila el SLA', () => {
    assert.equal(ESTADOS_ABIERTOS.length, 4);
    assert.ok(!ESTADOS_ABIERTOS.includes(EstadoOrden.EN_REVISION));
  });
});

describe('Lista de seguridad (RN1)', () => {
  test('aprobada cuando todos los ítems están marcados', () => {
    assert.ok(checklistAprobado({ guantes: true, senalizacion: true, escalera: true }));
  });
  test('rechazada si falta un ítem', () => {
    assert.equal(checklistAprobado({ guantes: true, escalera: false }), false);
  });
  test('rechazada si llega vacía', () => {
    assert.equal(checklistAprobado({}), false);
  });
});

describe('Consumo de insumos (RN4)', () => {
  test('120 m² con 15 ml/m² dan 1 800 ml (caso CP08)', () => {
    assert.equal(consumoTeorico(120, 15), 1800);
  });
  test('redondea a dos decimales', () => {
    assert.equal(consumoTeorico(42.5, 8.33), 354.03);
    assert.equal(redondear(1.005), 1.01);
  });
  test('rechaza superficies o rendimientos no positivos', () => {
    assert.throws(() => consumoTeorico(0, 15), RangeError);
    assert.throws(() => consumoTeorico(120, -1), RangeError);
  });
  test('la tolerancia es del 15 %', () => {
    assert.equal(TOLERANCIA_CONSUMO, 0.15);
  });
  test('2 070 ml sobre 1 800 ml está en el límite y no genera alerta', () => {
    assert.equal(excedeTolerancia(2070, 1800), false);
  });
  test('2 071 ml sobre 1 800 ml genera alerta (caso CP09)', () => {
    assert.ok(excedeTolerancia(2071, 1800));
  });
});

describe('Plazos del SLA (RF18)', () => {
  const limite = new Date('2026-11-16T16:00:00Z');
  test('a 45 minutos del límite no hay alerta', () => {
    assert.equal(nivelAlerta(limite, new Date('2026-11-16T15:15:00Z')), 0);
  });
  test('a 20 minutos del límite la orden está por vencer (caso CP13)', () => {
    assert.equal(nivelAlerta(limite, new Date('2026-11-16T15:40:00Z')), 1);
  });
  test('pasado el límite la orden está vencida', () => {
    assert.equal(nivelAlerta(limite, new Date('2026-11-16T16:00:01Z')), 2);
  });
  test('cumple si terminó en campo antes del límite', () => {
    assert.ok(cumpleSla(new Date('2026-11-16T15:59:00Z'), limite));
    assert.equal(cumpleSla(new Date('2026-11-16T16:01:00Z'), limite), false);
  });
});

describe('Geocerca de la evidencia (RN3)', () => {
  const edificio = { latitud: 40.754, longitud: -73.984, radioM: 150 };
  test('distancia conocida: un minuto de latitud son unos 1 853 m', () => {
    const d = distanciaMetros(40.75, -73.984, 40.75 + 1 / 60, -73.984);
    assert.ok(Math.abs(d - 1853) < 5, String(d));
  });
  test('una foto tomada en el edificio queda dentro', () => {
    assert.equal(fueraDeGeocerca({ latitud: 40.7541, longitud: -73.9841, precisionM: 10 }, edificio), false);
  });
  test('una foto tomada a 1 km queda marcada (caso CP11)', () => {
    assert.ok(fueraDeGeocerca({ latitud: 40.763, longitud: -73.984, precisionM: 10 }, edificio));
  });
  test('la precisión del GPS se descuenta a favor del operario', () => {
    // ~167 m del centro con 30 m de precisión: se acepta
    assert.equal(fueraDeGeocerca({ latitud: 40.7555, longitud: -73.984, precisionM: 30 }, edificio), false);
  });
  test('sin coordenadas la evidencia se marca para revisión', () => {
    assert.ok(fueraDeGeocerca({ latitud: null, longitud: null }, edificio));
  });
});

describe('Contraseñas y huella de evidencias', () => {
  test('la contraseña correcta se verifica y la incorrecta no', () => {
    const h = hashClave('Demo2026*');
    assert.ok(h.startsWith('scrypt$'));
    assert.ok(verificarClave('Demo2026*', h));
    assert.equal(verificarClave('demo2026*', h), false);
  });
  test('dos resúmenes de la misma contraseña son distintos (sal aleatoria)', () => {
    assert.notEqual(hashClave('Demo2026*'), hashClave('Demo2026*'));
  });
  test('un valor almacenado con otro formato se rechaza', () => {
    assert.equal(verificarClave('x', 'texto-plano'), false);
  });
  test('SHA-256 de "abc" coincide con el vector de prueba publicado', () => {
    assert.equal(sha256Hex(Buffer.from('abc')),
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  });
  test('un archivo alterado no coincide con la huella declarada (caso CP10)', () => {
    const original = Buffer.from('fotografia-original');
    const huella = sha256Hex(original);
    assert.ok(huellaCoincide(original, huella));
    assert.equal(huellaCoincide(Buffer.from('fotografia-alterada'), huella), false);
  });
});
