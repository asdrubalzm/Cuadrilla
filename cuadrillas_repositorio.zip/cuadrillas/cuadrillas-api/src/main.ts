import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors(); // el panel web se sirve desde otro origen durante el desarrollo
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  const puerto = Number(process.env.PORT ?? 3000);
  await app.listen(puerto, '0.0.0.0');
  console.log(`API de cuadrillas escuchando en el puerto ${puerto}`);
}
bootstrap();
