// Vigilancia de plazos frente al acuerdo de nivel de servicio (RF18).

export const VENTANA_AVISO_MIN = 30;

/** 0 = en plazo, 1 = por vencer (menos de 30 minutos), 2 = vencida. */
export function nivelAlerta(finPlan: Date, ahora: Date, ventanaMin = VENTANA_AVISO_MIN): 0 | 1 | 2 {
  const restanteMs = finPlan.getTime() - ahora.getTime();
  if (restanteMs < 0) return 2;
  if (restanteMs < ventanaMin * 60_000) return 1;
  return 0;
}

/** La orden cumple el SLA si se terminó en campo antes del límite, aunque sincronice después. */
export function cumpleSla(finReal: Date, finPlan: Date): boolean {
  return finReal.getTime() <= finPlan.getTime();
}
