// RN4: consumo teórico = superficie de la zona (m²) × rendimiento del insumo (ml/m²).

/** Tolerancia sobre el consumo teórico antes de generar una alerta (15 %). */
export const TOLERANCIA_CONSUMO = 0.15;

export function redondear(valor: number, decimales = 2): number {
  const f = 10 ** decimales;
  return Math.round((valor + Number.EPSILON) * f) / f;
}

export function consumoTeorico(superficieM2: number, rendimientoMlM2: number): number {
  if (superficieM2 <= 0 || rendimientoMlM2 <= 0) {
    throw new RangeError('La superficie y el rendimiento deben ser positivos');
  }
  return redondear(superficieM2 * rendimientoMlM2);
}

export function excedeTolerancia(
  real: number, teorico: number, tolerancia = TOLERANCIA_CONSUMO,
): boolean {
  return real > teorico * (1 + tolerancia);
}
