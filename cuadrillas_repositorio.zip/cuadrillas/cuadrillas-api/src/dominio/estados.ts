// Estados de la orden de trabajo y transiciones permitidas (diagrama de estados).
// Este archivo no depende de NestJS ni de la base: se prueba de forma aislada.

export enum EstadoOrden {
  PLANIFICADA = 'PLANIFICADA', ASIGNADA = 'ASIGNADA',
  EN_PREPARACION = 'EN_PREPARACION', EN_EJECUCION = 'EN_EJECUCION',
  BLOQUEADA = 'BLOQUEADA', FINALIZADA = 'FINALIZADA', EN_REVISION = 'EN_REVISION',
  APROBADA = 'APROBADA', RECHAZADA = 'RECHAZADA', CANCELADA = 'CANCELADA',
}

// Transiciones permitidas, tal como las define el diagrama de estados
export const TRANSICIONES: Record<EstadoOrden, EstadoOrden[]> = {
  PLANIFICADA: [EstadoOrden.ASIGNADA, EstadoOrden.CANCELADA],
  ASIGNADA: [EstadoOrden.EN_PREPARACION, EstadoOrden.CANCELADA],
  EN_PREPARACION: [EstadoOrden.EN_EJECUCION, EstadoOrden.BLOQUEADA],
  EN_EJECUCION: [EstadoOrden.FINALIZADA, EstadoOrden.BLOQUEADA],
  BLOQUEADA: [EstadoOrden.EN_EJECUCION, EstadoOrden.ASIGNADA],
  FINALIZADA: [EstadoOrden.EN_REVISION],
  EN_REVISION: [EstadoOrden.APROBADA, EstadoOrden.RECHAZADA],
  RECHAZADA: [EstadoOrden.EN_EJECUCION],
  APROBADA: [],
  CANCELADA: [],
};

export function puedeTransitar(actual: EstadoOrden, nuevo: EstadoOrden): boolean {
  return TRANSICIONES[actual].includes(nuevo);
}

/** Estados en los que la orden sigue en manos del operario y cuenta para el SLA. */
export const ESTADOS_ABIERTOS: EstadoOrden[] = [
  EstadoOrden.ASIGNADA, EstadoOrden.EN_PREPARACION,
  EstadoOrden.EN_EJECUCION, EstadoOrden.BLOQUEADA,
];

/** RN1: la lista de seguridad está aprobada solo si tiene ítems y todos están marcados. */
export function checklistAprobado(items: Record<string, boolean>): boolean {
  const valores = Object.values(items ?? {});
  return valores.length > 0 && valores.every((v) => v === true);
}
