// Integridad de la evidencia (RF10, RNF05): huella SHA-256 del archivo recibido.
import { createHash } from 'node:crypto';

export function sha256Hex(contenido: Buffer): string {
  return createHash('sha256').update(contenido).digest('hex');
}

export function huellaCoincide(contenido: Buffer, huellaDeclarada: string): boolean {
  return sha256Hex(contenido) === (huellaDeclarada ?? '').trim().toLowerCase();
}
