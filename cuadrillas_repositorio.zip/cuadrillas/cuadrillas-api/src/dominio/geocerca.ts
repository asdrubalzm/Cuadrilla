// RN3: la evidencia capturada fuera del radio del edificio se acepta, pero queda marcada.

const RADIO_TIERRA_M = 6_371_000;
const rad = (grados: number) => (grados * Math.PI) / 180;

/** Distancia en metros entre dos coordenadas (fórmula del semiverseno). */
export function distanciaMetros(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * RADIO_TIERRA_M * Math.asin(Math.sqrt(a));
}

/**
 * Sin coordenadas no se puede afirmar que la evidencia sea del edificio: se marca para revisión.
 * La precisión reportada por el teléfono se descuenta a favor del operario.
 */
export function fueraDeGeocerca(
  punto: { latitud?: number | null; longitud?: number | null; precisionM?: number | null },
  centro: { latitud: number; longitud: number; radioM: number },
): boolean {
  if (punto.latitud == null || punto.longitud == null) return true;
  const d = distanciaMetros(punto.latitud, punto.longitud, centro.latitud, centro.longitud);
  return d - (punto.precisionM ?? 0) > centro.radioM;
}
