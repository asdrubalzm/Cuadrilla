// Resumen de contraseñas con scrypt (módulo crypto de Node.js, sin dependencias nativas).
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const LONGITUD = 32;

/** Formato almacenado: scrypt$<sal en hex>$<resumen en hex> */
export function hashClave(clave: string, sal: Buffer = randomBytes(16)): string {
  const resumen = scryptSync(clave, sal, LONGITUD);
  return `scrypt$${sal.toString('hex')}$${resumen.toString('hex')}`;
}

export function verificarClave(clave: string, almacenada: string): boolean {
  const [esquema, salHex, resumenHex] = (almacenada ?? '').split('$');
  if (esquema !== 'scrypt' || !salHex || !resumenHex) return false;
  const esperado = Buffer.from(resumenHex, 'hex');
  const calculado = scryptSync(clave, Buffer.from(salHex, 'hex'), esperado.length);
  return esperado.length === calculado.length && timingSafeEqual(esperado, calculado);
}
