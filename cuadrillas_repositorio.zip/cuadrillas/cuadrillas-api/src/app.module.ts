import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { CalidadModule } from './calidad/calidad.module';
import { EvidenciasModule } from './evidencias/evidencias.module';
import { InventarioModule } from './inventario/inventario.module';
import { OrdenesModule } from './ordenes/ordenes.module';
import { ReportesModule } from './reportes/reportes.module';
import { SyncModule } from './sync/sync.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres' as const,
        url: config.get<string>(
          'DATABASE_URL', 'postgres://cuadrillas:cuadrillas@localhost:5432/cuadrillas'),
        autoLoadEntities: true,
        synchronize: false, // el esquema se crea con migrations/001_esquema_inicial.sql
      }),
    }),
    ScheduleModule.forRoot(),
    EventEmitterModule.forRoot(),
    AuthModule,
    OrdenesModule,
    SyncModule,
    EvidenciasModule,
    InventarioModule,
    CalidadModule,
    ReportesModule,
  ],
})
export class AppModule {}
