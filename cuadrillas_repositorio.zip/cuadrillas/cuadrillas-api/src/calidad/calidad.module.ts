import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrdenTrabajo } from '../ordenes/orden-trabajo.entity';
import { AlertasListener } from './alertas.listener';
import { EvaluacionCalidad } from './evaluacion.entity';
import { SlaScheduler } from './sla.scheduler';

@Module({
  imports: [TypeOrmModule.forFeature([OrdenTrabajo, EvaluacionCalidad])],
  providers: [SlaScheduler, AlertasListener],
})
export class CalidadModule {}
