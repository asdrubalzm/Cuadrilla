import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

/**
 * Punto único donde los eventos internos se convierten en avisos.
 * En el prototipo quedan en el registro del servidor y en el tablero (nivel de alerta);
 * el envío de notificaciones al teléfono (RF21) queda para una versión posterior.
 */
@Injectable()
export class AlertasListener {
  private readonly log = new Logger('Alertas');

  @OnEvent('sla.por_vencer')
  porVencer(e: { ordenId: string }) {
    this.log.warn(`Orden ${e.ordenId}: por vencer (menos de 30 minutos)`);
  }

  @OnEvent('sla.vencida')
  vencida(e: { ordenId: string }) {
    this.log.error(`Orden ${e.ordenId}: venció su plazo`);
  }

  @OnEvent('inventario.alerta')
  inventario(e: { insumoId: string; ordenId: string }) {
    this.log.warn(`Insumo ${e.insumoId}: consumo sobre la tolerancia o existencias bajo el mínimo (orden ${e.ordenId})`);
  }

  @OnEvent('orden.bloqueada')
  bloqueada(e: { ordenId: string; tipo: string }) {
    this.log.warn(`Orden ${e.ordenId}: bloqueada por ${e.tipo}`);
  }
}
