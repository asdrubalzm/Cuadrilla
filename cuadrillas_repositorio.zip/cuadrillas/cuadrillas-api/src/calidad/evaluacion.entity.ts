import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('evaluacion_calidad')
export class EvaluacionCalidad {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'orden_id', type: 'uuid' }) ordenId: string;
  @Column({ name: 'supervisor_id', type: 'uuid' }) supervisorId: string;
  @Column() resultado: string; // CONFORME o NO_CONFORME
  @Column({ type: 'smallint' }) puntaje: number;
  @Column({ type: 'text', nullable: true }) comentario?: string;
  @CreateDateColumn({ name: 'evaluado_en', type: 'timestamptz' }) evaluadoEn: Date;
}
