import { Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Cron, CronExpression } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { In, LessThan, Repository } from 'typeorm';
import { EstadoOrden, OrdenTrabajo } from '../ordenes/orden-trabajo.entity';

@Injectable()
export class SlaScheduler {
  constructor(
    @InjectRepository(OrdenTrabajo) private readonly repo: Repository<OrdenTrabajo>,
    private readonly eventos: EventEmitter2,
  ) {}

  @Cron(CronExpression.EVERY_5_MINUTES)
  async vigilarPlazos() {
    const abiertas = [
      EstadoOrden.ASIGNADA, EstadoOrden.EN_PREPARACION,
      EstadoOrden.EN_EJECUCION, EstadoOrden.BLOQUEADA,
    ];
    const enMediaHora = new Date(Date.now() + 30 * 60_000);
    const enRiesgo = await this.repo.find({
      where: { estado: In(abiertas), finPlan: LessThan(enMediaHora) },
    });

    for (const orden of enRiesgo) {
      // 2 = vencida, 1 = por vencer
      const nivel = orden.finPlan.getTime() < Date.now() ? 2 : 1;
      if (nivel > orden.nivelAlerta) { // avisa una sola vez por nivel
        await this.repo.update(orden.id, { nivelAlerta: nivel });
        this.eventos.emit(nivel === 2 ? 'sla.vencida' : 'sla.por_vencer', {
          ordenId: orden.id,
        });
      }
    }
  }
}
