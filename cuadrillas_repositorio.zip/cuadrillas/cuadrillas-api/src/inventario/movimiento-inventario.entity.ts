import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { numerico } from '../comun/numerico';

@Entity('movimiento_inventario')
export class MovimientoInventario {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'insumo_id', type: 'uuid' }) insumoId: string;
  @Column({ name: 'orden_id', type: 'uuid', nullable: true }) ordenId?: string;
  @Column({ name: 'usuario_id', type: 'uuid' }) usuarioId: string;
  @Column() tipo: string; // ENTRADA, SALIDA o AJUSTE
  @Column({ type: 'numeric', transformer: numerico }) cantidad: number;
  @CreateDateColumn({ type: 'timestamptz' }) fecha: Date;
}
