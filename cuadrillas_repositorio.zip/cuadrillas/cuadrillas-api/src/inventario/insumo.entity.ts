import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { numerico } from '../comun/numerico';

@Entity('insumo')
export class Insumo {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() nombre: string;
  @Column({ default: 'ml' }) unidad: string;
  @Column({ name: 'rendimiento_ml_m2', type: 'numeric', transformer: numerico }) rendimientoMlM2: number;
  @Column({ name: 'stock_actual', type: 'numeric', transformer: numerico }) stockActual: number;
  @Column({ name: 'stock_minimo', type: 'numeric', transformer: numerico }) stockMinimo: number;
  @Column({ name: 'costo_unitario', type: 'numeric', transformer: numerico }) costoUnitario: number;
}
