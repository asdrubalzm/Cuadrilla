import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { PeticionAutenticada } from '../comun/peticion';
import { Rol } from '../comun/rol.enum';
import { MovimientoDto } from './inventario.dto';
import { InventarioService } from './inventario.service';

@Controller('inventario')
@UseGuards(JwtAuthGuard, RolesGuard)
export class InventarioController {
  constructor(private readonly inventario: InventarioService) {}

  @Get('insumos')
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  listar() {
    return this.inventario.listar();
  }

  @Post('movimientos')
  @Roles(Rol.SUPERVISOR)
  registrar(@Body() dto: MovimientoDto, @Req() req: PeticionAutenticada) {
    return this.inventario.registrar(dto, req.user.id);
  }
}
