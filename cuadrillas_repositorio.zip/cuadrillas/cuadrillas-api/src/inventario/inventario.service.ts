import { Injectable, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { redondear } from '../dominio/consumo';
import { MovimientoDto } from './inventario.dto';
import { Insumo } from './insumo.entity';
import { MovimientoInventario } from './movimiento-inventario.entity';

@Injectable()
export class InventarioService {
  constructor(private readonly ds: DataSource) {}

  /** Existencias con su alerta de mínimo (RF14, RF15). */
  async listar() {
    const insumos = await this.ds.getRepository(Insumo).find({ order: { nombre: 'ASC' } });
    return insumos.map((i) => ({ ...i, bajoMinimo: i.stockActual <= i.stockMinimo }));
  }

  /** Ingresos y ajustes por conteo. Las salidas solo ocurren al cerrar una orden. */
  registrar(dto: MovimientoDto, usuarioId: string) {
    return this.ds.transaction(async (em) => {
      const insumo = await em.findOne(Insumo, {
        where: { id: dto.insumoId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!insumo) throw new NotFoundException('El insumo no existe');

      insumo.stockActual = dto.tipo === 'ENTRADA'
        ? redondear(insumo.stockActual + dto.cantidad)
        : redondear(dto.cantidad);
      await em.insert(MovimientoInventario, {
        insumoId: insumo.id, usuarioId, tipo: dto.tipo, cantidad: dto.cantidad,
      });
      return em.save(insumo);
    });
  }
}
