import { IsIn, IsNumber, IsPositive, IsUUID } from 'class-validator';

export class MovimientoDto {
  @IsUUID() insumoId: string;
  @IsIn(['ENTRADA', 'AJUSTE']) tipo: 'ENTRADA' | 'AJUSTE';
  /** ENTRADA suma la cantidad; AJUSTE fija las existencias en la cantidad contada. */
  @IsNumber() @IsPositive() cantidad: number;
}
