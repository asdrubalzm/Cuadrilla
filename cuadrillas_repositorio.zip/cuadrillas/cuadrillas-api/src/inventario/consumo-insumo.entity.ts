import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { numerico } from '../comun/numerico';

@Entity('consumo_insumo')
export class ConsumoInsumo {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'orden_id', type: 'uuid' }) ordenId: string;
  @Column({ name: 'insumo_id', type: 'uuid' }) insumoId: string;
  @Column({ name: 'cantidad_teorica', type: 'numeric', transformer: numerico }) cantidadTeorica: number;
  @Column({ name: 'cantidad_real', type: 'numeric', transformer: numerico }) cantidadReal: number;
}
