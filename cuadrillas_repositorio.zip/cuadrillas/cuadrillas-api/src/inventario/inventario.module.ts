import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConsumoInsumo } from './consumo-insumo.entity';
import { InventarioController } from './inventario.controller';
import { InventarioService } from './inventario.service';
import { Insumo } from './insumo.entity';
import { MovimientoInventario } from './movimiento-inventario.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Insumo, ConsumoInsumo, MovimientoInventario])],
  controllers: [InventarioController],
  providers: [InventarioService],
})
export class InventarioModule {}
