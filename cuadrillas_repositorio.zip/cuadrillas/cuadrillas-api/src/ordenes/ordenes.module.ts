import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from '../auth/auth.module';
import { ChecklistSeguridad } from './checklist-seguridad.entity';
import { Edificio } from './edificio.entity';
import { Impedimento } from './impedimento.entity';
import { OrdenTrabajo } from './orden-trabajo.entity';
import { OrdenesController } from './ordenes.controller';
import { OrdenesService } from './ordenes.service';
import { Sprint } from './sprint.entity';
import { SprintsController } from './sprints.controller';
import { Zona } from './zona.entity';

@Module({
  imports: [
    AuthModule,
    TypeOrmModule.forFeature([OrdenTrabajo, Zona, Edificio, Sprint, ChecklistSeguridad, Impedimento]),
  ],
  controllers: [OrdenesController, SprintsController],
  providers: [OrdenesService],
  exports: [OrdenesService],
})
export class OrdenesModule {}
