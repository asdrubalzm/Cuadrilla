import {
  Body, Controller, Get, HttpCode, Param, ParseUUIDPipe, Post, Query, Req, UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { PeticionAutenticada } from '../comun/peticion';
import { Rol } from '../comun/rol.enum';
import { AsignarOrdenDto, CrearOrdenesDto, EvaluarOrdenDto, FiltroOrdenesDto } from './ordenes.dto';
import { OrdenesService } from './ordenes.service';

@Controller('ordenes')
@UseGuards(JwtAuthGuard, RolesGuard)
export class OrdenesController {
  constructor(private readonly ordenes: OrdenesService) {}

  @Get('mias')
  @Roles(Rol.OPERARIO)
  listarMias(@Req() req: PeticionAutenticada, @Query('sprintId') sprintId?: string) {
    return this.ordenes.listarPorOperario(req.user.id, sprintId);
  }

  @Post(':id/asignar')
  @HttpCode(200)
  @Roles(Rol.SUPERVISOR)
  asignar(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: AsignarOrdenDto,
    @Req() req: PeticionAutenticada,
  ) {
    return this.ordenes.asignar(id, dto.operarioId, req.user.id);
  }

  @Post(':id/evaluacion')
  @HttpCode(200)
  @Roles(Rol.SUPERVISOR)
  evaluar(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: EvaluarOrdenDto,
    @Req() req: PeticionAutenticada,
  ) {
    return this.ordenes.evaluar(id, dto, req.user.id);
  }

  @Post(':id/desbloqueo')
  @HttpCode(200)
  @Roles(Rol.SUPERVISOR)
  desbloquear(@Param('id', ParseUUIDPipe) id: string) {
    return this.ordenes.resolverImpedimento(id);
  }

  @Post()
  @Roles(Rol.SUPERVISOR)
  crear(@Body() dto: CrearOrdenesDto) {
    return this.ordenes.crearOrdenes(dto);
  }

  @Get()
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  listar(@Query() filtro: FiltroOrdenesDto) {
    return this.ordenes.listar(filtro.sprintId, filtro.estado);
  }

  @Get(':id')
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  detalle(@Param('id', ParseUUIDPipe) id: string) {
    return this.ordenes.detalle(id);
  }
}
