import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('edificio')
export class Edificio {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() nombre: string;
  @Column() cliente: string;
  @Column() direccion: string;
  @Column({ type: 'double precision' }) latitud: number;
  @Column({ type: 'double precision' }) longitud: number;
  @Column({ name: 'radio_geocerca_m', type: 'int' }) radioGeocercaM: number;
}
