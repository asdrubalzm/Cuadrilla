import {
  BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { DataSource, EntityManager, In } from 'typeorm';
import { Usuario } from '../auth/usuario.entity';
import { EvaluacionCalidad } from '../calidad/evaluacion.entity';
import { Rol } from '../comun/rol.enum';
import { redondear, TOLERANCIA_CONSUMO } from '../dominio/consumo';
import { checklistAprobado, ESTADOS_ABIERTOS } from '../dominio/estados';
import { fueraDeGeocerca } from '../dominio/geocerca';
import { Evidencia } from '../evidencias/evidencia.entity';
import { ConsumoInsumo } from '../inventario/consumo-insumo.entity';
import { Insumo } from '../inventario/insumo.entity';
import { MovimientoInventario } from '../inventario/movimiento-inventario.entity';
import { ChecklistSeguridad } from './checklist-seguridad.entity';
import { Edificio } from './edificio.entity';
import { Impedimento } from './impedimento.entity';
import { EstadoOrden, OrdenTrabajo, TRANSICIONES } from './orden-trabajo.entity';
import {
  BloquearPayload, CrearOrdenesDto, CrearSprintDto, EvaluarOrdenDto, EvidenciaPayload,
  FinalizarPayload, IniciarPayload,
} from './ordenes.dto';
import { Sprint } from './sprint.entity';
import { Zona } from './zona.entity';

@Injectable()
export class OrdenesService {
  constructor(
    private readonly ds: DataSource,
    private readonly eventos: EventEmitter2,
  ) {}

  // ------------------------------------------------------------------ planificación (supervisor)

  listarSprints() {
    return this.ds.getRepository(Sprint).find({ order: { fechaInicio: 'DESC' } });
  }

  crearSprint(dto: CrearSprintDto) {
    if (dto.fechaFin < dto.fechaInicio) {
      throw new BadRequestException('La fecha de fin es anterior a la de inicio');
    }
    return this.ds.getRepository(Sprint).save({
      cuadrillaId: dto.cuadrillaId, fechaInicio: dto.fechaInicio,
      fechaFin: dto.fechaFin, objetivo: dto.objetivo,
    });
  }

  /** Crea una orden por cada zona indicada, con la misma ventana planificada. */
  async crearOrdenes(dto: CrearOrdenesDto) {
    const inicioPlan = new Date(dto.inicioPlan);
    const finPlan = new Date(dto.finPlan);
    if (finPlan <= inicioPlan) throw new BadRequestException('El fin debe ser posterior al inicio');

    const zonas = await this.ds.getRepository(Zona).findBy({ id: In(dto.zonaIds) });
    if (zonas.length !== dto.zonaIds.length) throw new NotFoundException('Alguna zona no existe');

    const repo = this.ds.getRepository(OrdenTrabajo);
    return repo.save(zonas.map((zona) => repo.create({
      sprintId: dto.sprintId, zonaId: zona.id, prioridad: dto.prioridad ?? 2, inicioPlan, finPlan,
    })));
  }

  /** Órdenes de un sprint con su zona y su operario, para el panel del supervisor. */
  listar(sprintId?: string, estado?: string) {
    return this.ds.query(
      `SELECT o.id, o.estado, o.prioridad, o.nivel_alerta AS "nivelAlerta",
              o.inicio_plan AS "inicioPlan", o.fin_plan AS "finPlan",
              o.inicio_real AS "inicioReal", o.fin_real AS "finReal",
              z.nombre AS "zonaNombre", z.tipo AS "zonaTipo", z.piso,
              z.superficie_m2::float AS "superficieM2",
              z.requiere_epp_altura AS "requiereEppAltura",
              o.operario_id AS "operarioId",
              CASE WHEN u.id IS NULL THEN NULL ELSE u.nombres || ' ' || u.apellidos END AS "operarioNombre"
         FROM orden_trabajo o
         JOIN zona z ON z.id = o.zona_id
         LEFT JOIN usuario u ON u.id = o.operario_id
        WHERE ($1::uuid IS NULL OR o.sprint_id = $1)
          AND ($2::text IS NULL OR o.estado::text = $2)
        ORDER BY o.prioridad, o.fin_plan, z.nombre`,
      [sprintId ?? null, estado ?? null],
    );
  }

  /** Asigna o reasigna una orden a un operario (RF06). */
  asignar(ordenId: string, operarioId: string, supervisorId: string) {
    return this.ds.transaction(async (em) => {
      const orden = await em.findOne(OrdenTrabajo, {
        where: { id: ordenId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!orden) throw new NotFoundException('La orden no existe');

      const operario = await em.findOneBy(Usuario, { id: operarioId, rol: Rol.OPERARIO, activo: true });
      if (!operario) throw new BadRequestException('El usuario indicado no es un operario activo');

      // Una orden ya asignada puede cambiar de operario mientras no haya empezado
      if (orden.estado !== EstadoOrden.ASIGNADA) {
        this.validarTransicion(orden.estado, EstadoOrden.ASIGNADA);
      }
      if (orden.estado === EstadoOrden.BLOQUEADA) {
        await em.update(Impedimento, { ordenId, estado: 'ABIERTO' },
          { estado: 'RESUELTO', resueltoEn: new Date() });
      }
      orden.operarioId = operarioId;
      orden.estado = EstadoOrden.ASIGNADA;
      await em.save(orden);
      this.eventos.emit('orden.asignada', { ordenId, operarioId, supervisorId });
      return orden;
    });
  }

  /** El supervisor resuelve el impedimento y la orden vuelve a manos del mismo operario. */
  resolverImpedimento(ordenId: string) {
    return this.ds.transaction(async (em) => {
      const orden = await em.findOne(OrdenTrabajo, {
        where: { id: ordenId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!orden) throw new NotFoundException('La orden no existe');

      const destino = orden.inicioReal ? EstadoOrden.EN_EJECUCION : EstadoOrden.ASIGNADA;
      this.validarTransicion(orden.estado, destino);
      await em.update(Impedimento, { ordenId, estado: 'ABIERTO' },
        { estado: 'RESUELTO', resueltoEn: new Date() });
      orden.estado = destino;
      return em.save(orden);
    });
  }

  /** Aprueba o rechaza una orden en revisión (RF16, RN5). */
  evaluar(ordenId: string, dto: EvaluarOrdenDto, supervisorId: string) {
    if (!dto.conforme && !dto.comentario?.trim()) {
      throw new BadRequestException('El rechazo requiere un comentario'); // RN5
    }
    return this.ds.transaction(async (em) => {
      const orden = await em.findOne(OrdenTrabajo, {
        where: { id: ordenId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!orden) throw new NotFoundException('La orden no existe');
      this.validarTransicion(
        orden.estado, dto.conforme ? EstadoOrden.APROBADA : EstadoOrden.RECHAZADA);

      await em.insert(EvaluacionCalidad, {
        ordenId, supervisorId, puntaje: dto.puntaje, comentario: dto.comentario?.trim(),
        resultado: dto.conforme ? 'CONFORME' : 'NO_CONFORME',
      });

      if (dto.conforme) {
        orden.estado = EstadoOrden.APROBADA;
      } else {
        // El rechazo no cierra la orden: la devuelve a ejecución como reproceso
        this.validarTransicion(EstadoOrden.RECHAZADA, EstadoOrden.EN_EJECUCION);
        orden.estado = EstadoOrden.EN_EJECUCION;
        this.eventos.emit('orden.rechazada', { ordenId, operarioId: orden.operarioId });
      }
      return em.save(orden);
    });
  }

  /** Todo lo que el supervisor necesita ver para calificar una orden. */
  async detalle(ordenId: string) {
    const [orden] = await this.ds.query(
      `SELECT o.id, o.estado, o.fin_plan AS "finPlan", o.inicio_real AS "inicioReal",
              o.fin_real AS "finReal", (o.fin_real <= o.fin_plan) AS "cumpleSla",
              z.nombre AS "zonaNombre", z.superficie_m2::float AS "superficieM2",
              u.nombres || ' ' || u.apellidos AS "operarioNombre"
         FROM orden_trabajo o
         JOIN zona z ON z.id = o.zona_id
         LEFT JOIN usuario u ON u.id = o.operario_id
        WHERE o.id = $1`, [ordenId]);
    if (!orden) throw new NotFoundException('La orden no existe');

    const [evidencias, checklist, consumos, impedimentos] = await Promise.all([
      this.ds.getRepository(Evidencia).find({ where: { ordenId }, order: { capturadoEn: 'ASC' } }),
      this.ds.getRepository(ChecklistSeguridad).find({ where: { ordenId }, order: { confirmadoEn: 'DESC' } }),
      this.ds.query(
        `SELECT i.nombre, c.cantidad_teorica::float AS teorica, c.cantidad_real::float AS real
           FROM consumo_insumo c JOIN insumo i ON i.id = c.insumo_id WHERE c.orden_id = $1`, [ordenId]),
      this.ds.getRepository(Impedimento).find({ where: { ordenId }, order: { reportadoEn: 'DESC' } }),
    ]);
    return { ...orden, evidencias, checklist: checklist[0] ?? null, consumos, impedimentos };
  }

  // ------------------------------------------------------------------ consulta del operario

  /** Órdenes abiertas del operario y catálogo de insumos, para guardarlos en el teléfono (RF07). */
  async listarPorOperario(operarioId: string, sprintId?: string) {
    const ordenes = await this.ds.query(
      `SELECT o.id, z.nombre AS "zonaNombre", z.superficie_m2::float AS "superficieM2",
              z.requiere_epp_altura AS "requiereEppAltura", o.fin_plan AS "finPlan",
              o.estado, o.inicio_real AS "inicioReal", o.prioridad
         FROM orden_trabajo o
         JOIN zona z ON z.id = o.zona_id
        WHERE o.operario_id = $1
          AND o.estado::text = ANY($2::text[])
          AND ($3::uuid IS NULL OR o.sprint_id = $3)
        ORDER BY o.prioridad, o.fin_plan`,
      [operarioId, ESTADOS_ABIERTOS, sprintId ?? null],
    );
    const insumos = await this.ds.query(
      `SELECT id, nombre, rendimiento_ml_m2::float AS "rendimientoMlM2" FROM insumo ORDER BY nombre`);
    return { ordenes, insumos };
  }

  // ------------------------------------------------------------------ operaciones que llegan por lotes
  // Reciben el EntityManager de la transacción abierta por SyncService.procesarLote.

  async iniciar(em: EntityManager, p: IniciarPayload, usuarioId: string) {
    const orden = await this.bloquearFila(em, p.ordenId, usuarioId);
    if (!checklistAprobado(p.checklist)) {
      throw new ConflictException('La lista de seguridad no está completa'); // RN1
    }
    if (orden.estado === EstadoOrden.ASIGNADA) {
      this.validarTransicion(orden.estado, EstadoOrden.EN_PREPARACION);
      orden.estado = EstadoOrden.EN_PREPARACION;
    }
    this.validarTransicion(orden.estado, EstadoOrden.EN_EJECUCION);

    await em.insert(ChecklistSeguridad, {
      ordenId: orden.id, items: p.checklist, aprobado: true, confirmadoEn: new Date(p.inicioReal),
    });
    orden.inicioReal = orden.inicioReal ?? new Date(p.inicioReal);
    orden.estado = EstadoOrden.EN_EJECUCION;
    await em.save(orden);
  }

  async bloquear(em: EntityManager, p: BloquearPayload, usuarioId: string) {
    const orden = await this.bloquearFila(em, p.ordenId, usuarioId);
    if (orden.estado === EstadoOrden.ASIGNADA) {
      // El operario detectó el faltante mientras se preparaba
      this.validarTransicion(orden.estado, EstadoOrden.EN_PREPARACION);
      orden.estado = EstadoOrden.EN_PREPARACION;
    }
    this.validarTransicion(orden.estado, EstadoOrden.BLOQUEADA);

    await em.insert(Impedimento, {
      ordenId: orden.id, tipo: p.tipo, descripcion: p.descripcion,
      estado: 'ABIERTO', reportadoEn: new Date(p.reportadoEn),
    });
    orden.estado = EstadoOrden.BLOQUEADA;
    await em.save(orden);
    this.eventos.emit('orden.bloqueada', { ordenId: orden.id, tipo: p.tipo });
  }

  async finalizar(em: EntityManager, p: FinalizarPayload, usuarioId: string) {
    // Bloquea la fila para que dos peticiones no modifiquen la misma orden a la vez
    const orden = await em.findOneOrFail(OrdenTrabajo, {
      where: { id: p.ordenId },
      lock: { mode: 'pessimistic_write' },
    });
    if (orden.operarioId !== usuarioId) throw new ForbiddenException('Orden ajena');
    this.validarTransicion(orden.estado, EstadoOrden.FINALIZADA);

    const zona = await em.findOneByOrFail(Zona, { id: orden.zonaId });
    const insumos = await em.find(Insumo, {
      where: { id: In(Object.keys(p.consumoReal)) },
      lock: { mode: 'pessimistic_write' },
    });

    for (const insumo of insumos) {
      const teorico = redondear(zona.superficieM2 * insumo.rendimientoMlM2); // RN4
      const real = p.consumoReal[insumo.id];
      if (real > insumo.stockActual) throw new ConflictException('Stock insuficiente');

      await em.insert(ConsumoInsumo, {
        ordenId: orden.id, insumoId: insumo.id,
        cantidadTeorica: teorico, cantidadReal: real,
      });
      await em.insert(MovimientoInventario, {
        insumoId: insumo.id, ordenId: orden.id, usuarioId,
        tipo: 'SALIDA', cantidad: real,
      });
      insumo.stockActual = redondear(insumo.stockActual - real);
      await em.save(insumo);

      const exceso = real > teorico * (1 + TOLERANCIA_CONSUMO);
      if (exceso || insumo.stockActual <= insumo.stockMinimo) {
        this.eventos.emit('inventario.alerta', {
          insumoId: insumo.id, ordenId: orden.id,
        });
      }
    }

    // RN3: la evidencia fuera del radio del edificio se acepta, pero queda marcada
    const edificio = await em.findOneByOrFail(Edificio, { id: zona.edificioId });
    await em.insert(Evidencia, this.nuevaEvidencia(p.evidencia, orden.id, edificio));

    orden.finReal = new Date(p.finReal);
    orden.estado = EstadoOrden.EN_REVISION; // al llegar al servidor pasa a revisión
    // Si cumplió a tiempo pero sincronizó tarde, se retira la alerta de atraso
    if (orden.finReal <= orden.finPlan) orden.nivelAlerta = 0;
    await em.save(orden);
  }

  private validarTransicion(actual: EstadoOrden, nuevo: EstadoOrden) {
    if (!TRANSICIONES[actual].includes(nuevo)) {
      throw new ConflictException(`No se puede pasar de ${actual} a ${nuevo}`);
    }
  }

  private async bloquearFila(em: EntityManager, ordenId: string, usuarioId: string) {
    const orden = await em.findOne(OrdenTrabajo, {
      where: { id: ordenId },
      lock: { mode: 'pessimistic_write' },
    });
    if (!orden) throw new NotFoundException('La orden no existe');
    if (orden.operarioId !== usuarioId) throw new ForbiddenException('Orden ajena');
    return orden;
  }

  private nuevaEvidencia(e: EvidenciaPayload, ordenId: string, edificio: Edificio) {
    return {
      id: e.id, ordenId, tipo: e.tipo, hashSha256: e.hashSha256.toLowerCase(),
      latitud: e.latitud ?? undefined, longitud: e.longitud ?? undefined,
      precisionM: e.precisionM ?? undefined,
      capturadoEn: new Date(e.capturadoEn), archivoRecibido: false,
      fueraDeGeocerca: fueraDeGeocerca(e, {
        latitud: edificio.latitud, longitud: edificio.longitud, radioM: edificio.radioGeocercaM,
      }),
    };
  }
}
