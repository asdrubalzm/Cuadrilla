import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { numerico } from '../comun/numerico';

@Entity('zona')
export class Zona {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'edificio_id', type: 'uuid' }) edificioId: string;
  @Column() nombre: string;
  @Column({ type: 'int' }) piso: number;
  @Column() tipo: string;
  @Column({ name: 'superficie_m2', type: 'numeric', transformer: numerico }) superficieM2: number;
  @Column({ name: 'requiere_epp_altura', default: false }) requiereEppAltura: boolean;
}
