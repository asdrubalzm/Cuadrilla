import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('impedimento')
export class Impedimento {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'orden_id', type: 'uuid' }) ordenId: string;
  @Column() tipo: string;
  @Column() descripcion: string;
  @Column({ default: 'ABIERTO' }) estado: string;
  @Column({ name: 'reportado_en', type: 'timestamptz' }) reportadoEn: Date;
  @Column({ name: 'resuelto_en', type: 'timestamptz', nullable: true }) resueltoEn?: Date;
}
