import { Column, Entity, PrimaryGeneratedColumn, VersionColumn } from 'typeorm';
import { EstadoOrden, TRANSICIONES } from '../dominio/estados';

// El enumerado y la tabla de transiciones viven en src/dominio/estados.ts para poder
// probarlos sin base de datos; se reexportan aquí porque describen a esta entidad.
export { EstadoOrden, TRANSICIONES };

@Entity('orden_trabajo')
export class OrdenTrabajo {
  @PrimaryGeneratedColumn('uuid') id: string;

  @Column({ name: 'sprint_id', type: 'uuid' }) sprintId: string;
  @Column({ name: 'zona_id', type: 'uuid' }) zonaId: string;
  @Column({ name: 'operario_id', type: 'uuid', nullable: true }) operarioId?: string;
  @Column({ name: 'sla_id', type: 'uuid', nullable: true }) slaId?: string;

  @Column({ type: 'enum', enum: EstadoOrden, enumName: 'estado_orden', default: EstadoOrden.PLANIFICADA })
  estado: EstadoOrden;

  @Column({ type: 'smallint', default: 2 }) prioridad: number;

  @Column({ name: 'inicio_plan', type: 'timestamptz' }) inicioPlan: Date;
  @Column({ name: 'fin_plan', type: 'timestamptz' }) finPlan: Date;

  @Column({ name: 'inicio_real', type: 'timestamptz', nullable: true })
  inicioReal?: Date;

  @Column({ name: 'fin_real', type: 'timestamptz', nullable: true })
  finReal?: Date;

  @Column({ name: 'nivel_alerta', type: 'smallint', default: 0 }) nivelAlerta: number;

  @VersionColumn() version: number; // control de concurrencia optimista
}
