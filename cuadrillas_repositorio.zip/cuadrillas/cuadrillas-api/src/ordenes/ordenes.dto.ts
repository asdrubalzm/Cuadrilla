import {
  ArrayNotEmpty, IsBoolean, IsDateString, IsIn, IsInt, IsOptional, IsString,
  IsUUID, Max, Min, MinLength,
} from 'class-validator';

export class CrearSprintDto {
  @IsUUID() cuadrillaId: string;
  @IsDateString() fechaInicio: string;
  @IsDateString() fechaFin: string;
  @IsString() @MinLength(5) objetivo: string;
}

export class CrearOrdenesDto {
  @IsUUID() sprintId: string;
  @ArrayNotEmpty() @IsUUID(undefined, { each: true }) zonaIds: string[];
  @IsDateString() inicioPlan: string;
  @IsDateString() finPlan: string;
  @IsOptional() @IsInt() @Min(1) @Max(3) prioridad?: number;
}

export class AsignarOrdenDto {
  @IsUUID() operarioId: string;
}

export class EvaluarOrdenDto {
  @IsBoolean() conforme: boolean;
  @IsInt() @Min(1) @Max(5) puntaje: number;
  @IsOptional() @IsString() comentario?: string;
}

// ---- Contenido de las operaciones que el teléfono envía por lotes (ver sync/)

export interface IniciarPayload {
  ordenId: string;
  inicioReal: string;                    // ISO 8601, hora del teléfono en UTC
  checklist: Record<string, boolean>;    // ítem -> marcado
}

export interface EvidenciaPayload {
  id: string;
  tipo: 'ANTES' | 'DESPUES' | 'INCIDENTE';
  hashSha256: string;
  latitud?: number | null;
  longitud?: number | null;
  precisionM?: number | null;
  capturadoEn: string;
}

export interface FinalizarPayload {
  ordenId: string;
  finReal: string;
  evidencia: EvidenciaPayload;
  consumoReal: Record<string, number>;   // idInsumo -> mililitros usados
}

export interface BloquearPayload {
  ordenId: string;
  tipo: 'INSUMO' | 'EPP' | 'CLIMA' | 'ACCESO' | 'OTRO';
  descripcion: string;
  reportadoEn: string;
}

export class FiltroOrdenesDto {
  @IsOptional() @IsUUID() sprintId?: string;
  @IsOptional() @IsIn([
    'PLANIFICADA', 'ASIGNADA', 'EN_PREPARACION', 'EN_EJECUCION', 'BLOQUEADA',
    'FINALIZADA', 'EN_REVISION', 'APROBADA', 'RECHAZADA', 'CANCELADA',
  ]) estado?: string;
}
