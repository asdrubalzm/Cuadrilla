import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('checklist_seguridad')
export class ChecklistSeguridad {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'orden_id', type: 'uuid' }) ordenId: string;
  @Column({ type: 'jsonb' }) items: Record<string, boolean>;
  @Column() aprobado: boolean;
  @Column({ name: 'confirmado_en', type: 'timestamptz' }) confirmadoEn: Date;
}
