import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('sprint')
export class Sprint {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ name: 'cuadrilla_id', type: 'uuid' }) cuadrillaId: string;
  @Column({ name: 'fecha_inicio', type: 'date' }) fechaInicio: string;
  @Column({ name: 'fecha_fin', type: 'date' }) fechaFin: string;
  @Column() objetivo: string;
  @Column({ default: 'ABIERTO' }) estado: string;
}
