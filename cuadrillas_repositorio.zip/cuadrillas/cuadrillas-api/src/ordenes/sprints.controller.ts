import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { Rol } from '../comun/rol.enum';
import { CrearSprintDto } from './ordenes.dto';
import { OrdenesService } from './ordenes.service';

@Controller('sprints')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SprintsController {
  constructor(private readonly ordenes: OrdenesService) {}

  @Get()
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  listar() {
    return this.ordenes.listarSprints();
  }

  @Post()
  @Roles(Rol.SUPERVISOR)
  crear(@Body() dto: CrearSprintDto) {
    return this.ordenes.crearSprint(dto);
  }
}
