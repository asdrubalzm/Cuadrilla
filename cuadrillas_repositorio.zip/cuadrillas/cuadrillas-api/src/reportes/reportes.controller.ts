import {
  BadRequestException, Controller, Get, Param, ParseUUIDPipe, Query, UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { Rol } from '../comun/rol.enum';
import { ReportesService } from './reportes.service';

@Controller()
@UseGuards(JwtAuthGuard, RolesGuard)
export class ReportesController {
  constructor(private readonly reportes: ReportesService) {}

  @Get('tablero/sprints/:id')
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  tablero(@Param('id', ParseUUIDPipe) id: string) {
    return this.reportes.tablero(id);
  }

  /** Por defecto, los últimos 30 días. Fechas en formato AAAA-MM-DD. */
  @Get('reportes/sla')
  @Roles(Rol.GERENTE, Rol.SUPERVISOR)
  sla(@Query('desde') desde?: string, @Query('hasta') hasta?: string) {
    const fin = hasta ? new Date(hasta) : new Date(Date.now() + 24 * 3600_000);
    const inicio = desde ? new Date(desde) : new Date(fin.getTime() - 30 * 24 * 3600_000);
    if (Number.isNaN(inicio.getTime()) || Number.isNaN(fin.getTime()) || fin <= inicio) {
      throw new BadRequestException('Rango de fechas inválido');
    }
    return this.reportes.sla(inicio, fin);
  }
}
