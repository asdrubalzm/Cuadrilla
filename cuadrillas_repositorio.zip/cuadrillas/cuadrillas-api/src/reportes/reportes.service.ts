import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class ReportesService {
  constructor(private readonly ds: DataSource) {}

  /** Estado del sprint: conteo por estado, carga por operario, bloqueadas y atrasadas (RF17). */
  async tablero(sprintId: string) {
    const [porEstado, porOperario, bloqueadas, enRiesgo] = await Promise.all([
      this.ds.query(
        `SELECT estado, count(*)::int AS total
           FROM orden_trabajo WHERE sprint_id = $1 GROUP BY estado ORDER BY estado`, [sprintId]),
      this.ds.query(
        `SELECT u.nombres || ' ' || u.apellidos AS operario,
                count(*)::int AS asignadas,
                count(*) FILTER (WHERE o.estado IN ('EN_REVISION', 'APROBADA'))::int AS terminadas,
                COALESCE(sum(z.superficie_m2), 0)::float AS "superficieM2"
           FROM orden_trabajo o
           JOIN usuario u ON u.id = o.operario_id
           JOIN zona z ON z.id = o.zona_id
          WHERE o.sprint_id = $1 AND o.estado <> 'CANCELADA'
          GROUP BY u.id, u.nombres, u.apellidos ORDER BY operario`, [sprintId]),
      this.ds.query(
        `SELECT o.id, z.nombre AS "zonaNombre", i.tipo, i.descripcion, i.reportado_en AS "reportadoEn"
           FROM orden_trabajo o
           JOIN zona z ON z.id = o.zona_id
           JOIN impedimento i ON i.orden_id = o.id AND i.estado = 'ABIERTO'
          WHERE o.sprint_id = $1 AND o.estado = 'BLOQUEADA'
          ORDER BY i.reportado_en`, [sprintId]),
      this.ds.query(
        `SELECT o.id, z.nombre AS "zonaNombre", o.fin_plan AS "finPlan", o.nivel_alerta AS "nivelAlerta"
           FROM orden_trabajo o JOIN zona z ON z.id = o.zona_id
          WHERE o.sprint_id = $1 AND o.nivel_alerta > 0
            AND o.estado IN ('ASIGNADA', 'EN_PREPARACION', 'EN_EJECUCION', 'BLOQUEADA')
          ORDER BY o.fin_plan`, [sprintId]),
    ]);
    return { porEstado, porOperario, bloqueadas, enRiesgo };
  }

  /** Cumplimiento del SLA, evidencia verificable y costo de insumos por periodo (RF19). */
  async sla(desde: Date, hasta: Date) {
    const [cumplimiento, evidencia, insumos] = await Promise.all([
      this.ds.query(
        `SELECT e.nombre AS edificio,
                count(*)::int AS planificadas,
                count(*) FILTER (WHERE o.fin_real IS NOT NULL)::int AS ejecutadas,
                count(*) FILTER (WHERE o.fin_real <= o.fin_plan)::int AS "aTiempo",
                round(100.0 * count(*) FILTER (WHERE o.fin_real <= o.fin_plan)
                      / NULLIF(count(*) FILTER (WHERE o.fin_real IS NOT NULL), 0), 1)::float AS "cumplimientoPct"
           FROM orden_trabajo o
           JOIN zona z ON z.id = o.zona_id
           JOIN edificio e ON e.id = z.edificio_id
          WHERE o.fin_plan >= $1 AND o.fin_plan < $2 AND o.estado <> 'CANCELADA'
          GROUP BY e.nombre ORDER BY e.nombre`, [desde, hasta]),
      this.ds.query(
        `SELECT count(*)::int AS ejecutadas,
                count(*) FILTER (WHERE EXISTS (
                  SELECT 1 FROM evidencia ev
                   WHERE ev.orden_id = o.id AND ev.archivo_recibido
                     AND ev.latitud IS NOT NULL AND NOT ev.fuera_de_geocerca))::int AS "conEvidenciaVerificable"
           FROM orden_trabajo o
          WHERE o.fin_real IS NOT NULL AND o.fin_plan >= $1 AND o.fin_plan < $2`, [desde, hasta]),
      this.ds.query(
        `SELECT i.nombre,
                sum(c.cantidad_teorica)::float AS teorico,
                sum(c.cantidad_real)::float AS real,
                round(100.0 * (sum(c.cantidad_real) - sum(c.cantidad_teorica))
                      / NULLIF(sum(c.cantidad_teorica), 0), 1)::float AS "desviacionPct",
                round(sum(c.cantidad_real * i.costo_unitario), 2)::float AS costo
           FROM consumo_insumo c
           JOIN insumo i ON i.id = c.insumo_id
           JOIN orden_trabajo o ON o.id = c.orden_id
          WHERE o.fin_plan >= $1 AND o.fin_plan < $2
          GROUP BY i.nombre ORDER BY i.nombre`, [desde, hasta]),
    ]);
    return { desde, hasta, cumplimiento, evidencia: evidencia[0], insumos };
  }
}
