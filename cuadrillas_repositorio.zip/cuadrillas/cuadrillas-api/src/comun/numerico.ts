import { ValueTransformer } from 'typeorm';

/** PostgreSQL entrega las columnas numeric como texto; la entidad las expone como número. */
export const numerico: ValueTransformer = {
  to: (valor?: number | null) => valor,
  from: (valor?: string | null) => (valor == null ? null : Number(valor)),
};
