import { Request } from 'express';
import { Rol } from './rol.enum';

/** Usuario que la estrategia JWT deja en la petición. */
export interface UsuarioAutenticado {
  id: string;
  rol: Rol;
  nombre: string;
}

export interface PeticionAutenticada extends Request {
  user: UsuarioAutenticado;
}
