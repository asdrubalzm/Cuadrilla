import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity('evidencia')
export class Evidencia {
  @PrimaryColumn('uuid') id: string; // lo genera el teléfono
  @Column({ name: 'orden_id', type: 'uuid' }) ordenId: string;
  @Column() tipo: string; // ANTES, DESPUES o INCIDENTE
  @Column({ name: 'ruta_archivo', type: 'text', nullable: true }) rutaArchivo?: string;
  @Column({ name: 'hash_sha256', type: 'char', length: 64 }) hashSha256: string;
  @Column({ type: 'double precision', nullable: true }) latitud?: number;
  @Column({ type: 'double precision', nullable: true }) longitud?: number;
  @Column({ name: 'precision_m', type: 'double precision', nullable: true }) precisionM?: number;
  @Column({ name: 'capturado_en', type: 'timestamptz' }) capturadoEn: Date;
  @Column({ name: 'recibido_en', type: 'timestamptz', default: () => 'now()' }) recibidoEn: Date;
  @Column({ name: 'archivo_recibido', default: false }) archivoRecibido: boolean;
  @Column({ name: 'fuera_de_geocerca', default: false }) fueraDeGeocerca: boolean;
}
