import {
  ForbiddenException, Injectable, NotFoundException, UnprocessableEntityException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { mkdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { DataSource } from 'typeorm';
import { huellaCoincide } from '../dominio/huella';
import { OrdenTrabajo } from '../ordenes/orden-trabajo.entity';
import { Evidencia } from './evidencia.entity';

@Injectable()
export class EvidenciasService {
  private readonly almacen: string;

  constructor(private readonly ds: DataSource, config: ConfigService) {
    this.almacen = resolve(config.get<string>('ALMACEN_EVIDENCIAS', './almacen'));
  }

  /**
   * Recibe el archivo de una evidencia cuyos metadatos ya llegaron con la orden.
   * Recalcula la huella SHA-256 y rechaza el archivo si no coincide (RF10, RNF05).
   */
  async recibirArchivo(evidenciaId: string, contenido: Buffer, usuarioId: string) {
    const repo = this.ds.getRepository(Evidencia);
    const evidencia = await repo.findOneBy({ id: evidenciaId });
    // 404: la orden aún no se sincronizó; el teléfono lo reintenta después
    if (!evidencia) throw new NotFoundException('La evidencia todavía no está registrada');

    const orden = await this.ds.getRepository(OrdenTrabajo).findOneBy({ id: evidencia.ordenId });
    if (orden?.operarioId !== usuarioId) throw new ForbiddenException('Evidencia ajena');

    if (evidencia.archivoRecibido) return { id: evidencia.id, estado: 'YA_RECIBIDA' };

    if (!huellaCoincide(contenido, evidencia.hashSha256)) {
      throw new UnprocessableEntityException('El archivo no coincide con la huella registrada');
    }

    await mkdir(this.almacen, { recursive: true });
    const nombre = `${evidencia.id}.jpg`; // el nombre sale del UUID, no de lo que envía el cliente
    await writeFile(join(this.almacen, nombre), contenido);
    await repo.update(evidencia.id, { rutaArchivo: nombre, archivoRecibido: true });
    return { id: evidencia.id, estado: 'RECIBIDA' };
  }

  async rutaDeArchivo(evidenciaId: string) {
    const evidencia = await this.ds.getRepository(Evidencia).findOneBy({ id: evidenciaId });
    if (!evidencia?.archivoRecibido || !evidencia.rutaArchivo) {
      throw new NotFoundException('La evidencia no tiene archivo');
    }
    return join(this.almacen, evidencia.rutaArchivo);
  }
}
