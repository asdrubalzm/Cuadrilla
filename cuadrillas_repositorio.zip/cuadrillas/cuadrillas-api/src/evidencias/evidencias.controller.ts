import {
  BadRequestException, Body, Controller, Get, Param, ParseUUIDPipe, Post, Req, StreamableFile,
  UploadedFile, UseGuards, UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { createReadStream } from 'node:fs';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { PeticionAutenticada } from '../comun/peticion';
import { Rol } from '../comun/rol.enum';
import { EvidenciasService } from './evidencias.service';

const TAMANO_MAXIMO = 8 * 1024 * 1024; // 8 MB por fotografía

@Controller('evidencias')
@UseGuards(JwtAuthGuard, RolesGuard)
export class EvidenciasController {
  constructor(private readonly evidencias: EvidenciasService) {}

  /** Formulario multipart con los campos evidenciaId y archivo. */
  @Post()
  @Roles(Rol.OPERARIO)
  @UseInterceptors(FileInterceptor('archivo', { limits: { fileSize: TAMANO_MAXIMO } }))
  subir(
    @UploadedFile() archivo: Express.Multer.File,
    @Body('evidenciaId', ParseUUIDPipe) evidenciaId: string,
    @Req() req: PeticionAutenticada,
  ) {
    if (!archivo?.buffer?.length) throw new BadRequestException('Falta el archivo');
    return this.evidencias.recibirArchivo(evidenciaId, archivo.buffer, req.user.id);
  }

  @Get(':id/archivo')
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  async ver(@Param('id', ParseUUIDPipe) id: string) {
    const ruta = await this.evidencias.rutaDeArchivo(id);
    return new StreamableFile(createReadStream(ruta), { type: 'image/jpeg' });
  }
}
