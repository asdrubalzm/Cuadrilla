import { Type } from 'class-transformer';
import { ArrayMaxSize, IsArray, IsObject, IsString, IsUUID, ValidateNested } from 'class-validator';

export class OperacionDto {
  @IsUUID() operacionUuid: string;
  @IsString() entidad: string;
  @IsString() accion: string; // INICIAR, FINALIZAR o BLOQUEAR
  @IsObject() payload: any;
}

export class LoteDto {
  @IsArray() @ArrayMaxSize(50)
  @ValidateNested({ each: true }) @Type(() => OperacionDto)
  operaciones: OperacionDto[];
}

export interface ResultadoOperacion {
  operacionUuid: string;
  estado: 'APLICADA' | 'DUPLICADA' | 'RECHAZADA';
  detalle?: string;
}
