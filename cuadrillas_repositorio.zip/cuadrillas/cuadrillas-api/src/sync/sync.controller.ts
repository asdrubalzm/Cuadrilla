import { Body, Controller, Headers, HttpCode, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles, RolesGuard } from '../auth/roles.guard';
import { PeticionAutenticada } from '../comun/peticion';
import { Rol } from '../comun/rol.enum';
import { LoteDto } from './sync.dto';
import { SyncService } from './sync.service';

@Controller('sync')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SyncController {
  constructor(private readonly sync: SyncService) {}

  /** Recibe hasta 50 operaciones generadas sin conexión y responde el resultado de cada una. */
  @Post('lote')
  @HttpCode(200)
  @Roles(Rol.OPERARIO)
  lote(
    @Body() dto: LoteDto,
    @Req() req: PeticionAutenticada,
    @Headers('x-dispositivo') dispositivo?: string,
  ) {
    return this.sync.procesarLote(dto.operaciones, req.user.id, dispositivo ?? 'desconocido');
  }
}
