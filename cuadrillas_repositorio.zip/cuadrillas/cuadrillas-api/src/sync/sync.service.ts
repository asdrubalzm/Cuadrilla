import { BadRequestException, Injectable } from '@nestjs/common';
import { DataSource, QueryFailedError } from 'typeorm';
import { OrdenesService } from '../ordenes/ordenes.service';
import { SyncOperacion } from './sync-operacion.entity';
import { OperacionDto, ResultadoOperacion } from './sync.dto';

@Injectable()
export class SyncService {
  constructor(
    private readonly ds: DataSource,
    private readonly ordenes: OrdenesService,
  ) {}

  async procesarLote(ops: OperacionDto[], usuarioId: string, dispositivoId: string) {
    const resultados: ResultadoOperacion[] = [];

    for (const op of ops) { // se respetan en el orden en que el teléfono las generó
      try {
        const estado = await this.ds.transaction(async (em) => {
          const previa = await em.findOneBy(SyncOperacion, {
            operacionUuid: op.operacionUuid,
          });
          if (previa) return 'DUPLICADA' as const;

          switch (op.accion) {
            case 'INICIAR':
              await this.ordenes.iniciar(em, op.payload, usuarioId);
              break;
            case 'FINALIZAR':
              await this.ordenes.finalizar(em, op.payload, usuarioId);
              break;
            case 'BLOQUEAR':
              await this.ordenes.bloquear(em, op.payload, usuarioId);
              break;
            default:
              throw new BadRequestException(`Acción desconocida: ${op.accion}`);
          }

          await em.insert(SyncOperacion, {
            operacionUuid: op.operacionUuid, usuarioId, dispositivoId,
            entidad: op.entidad, accion: op.accion, resultado: 'APLICADA',
          });
          return 'APLICADA' as const;
        });
        resultados.push({ operacionUuid: op.operacionUuid, estado });
      } catch (e) {
        // 23505: clave duplicada en PostgreSQL (dos envíos simultáneos del UUID)
        const repetida =
          e instanceof QueryFailedError && e.driverError?.code === '23505';
        resultados.push({
          operacionUuid: op.operacionUuid,
          estado: repetida ? 'DUPLICADA' : 'RECHAZADA',
          detalle: repetida ? undefined : (e as Error).message,
        });
      }
    }
    return { resultados };
  }
}
