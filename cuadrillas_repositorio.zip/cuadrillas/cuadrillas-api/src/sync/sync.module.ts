import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrdenesModule } from '../ordenes/ordenes.module';
import { SyncOperacion } from './sync-operacion.entity';
import { SyncController } from './sync.controller';
import { SyncService } from './sync.service';

@Module({
  imports: [OrdenesModule, TypeOrmModule.forFeature([SyncOperacion])],
  controllers: [SyncController],
  providers: [SyncService],
})
export class SyncModule {}
