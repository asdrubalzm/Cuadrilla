import { Column, CreateDateColumn, Entity, PrimaryColumn } from 'typeorm';

@Entity('sync_operacion')
export class SyncOperacion {
  @PrimaryColumn({ name: 'operacion_uuid', type: 'uuid' }) operacionUuid: string;
  @Column({ name: 'usuario_id', type: 'uuid' }) usuarioId: string;
  @Column({ name: 'dispositivo_id' }) dispositivoId: string;
  @Column() entidad: string;
  @Column() accion: string;
  @Column() resultado: string;
  @CreateDateColumn({ name: 'recibido_en', type: 'timestamptz' }) recibidoEn: Date;
}
