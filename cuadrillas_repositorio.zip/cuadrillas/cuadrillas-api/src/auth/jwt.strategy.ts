import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { UsuarioAutenticado } from '../comun/peticion';
import { Rol } from '../comun/rol.enum';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(config: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.get<string>('JWT_SECRET', 'solo-para-pruebas-locales'),
    });
  }

  // Lo que devuelve este método queda disponible como req.user
  validate(payload: { sub: string; rol: Rol; nombre: string }): UsuarioAutenticado {
    return { id: payload.sub, rol: payload.rol, nombre: payload.nombre };
  }
}
