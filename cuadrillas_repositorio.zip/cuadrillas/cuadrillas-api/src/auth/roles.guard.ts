import { CanActivate, ExecutionContext, Injectable, SetMetadata } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Rol } from '../comun/rol.enum';

export const Roles = (...roles: Rol[]) => SetMetadata('roles', roles);

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const permitidos = this.reflector.getAllAndOverride<Rol[]>('roles', [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!permitidos?.length) return true; // ruta sin restricción de rol

    const { user } = ctx.switchToHttp().getRequest();
    return permitidos.includes(user?.rol);
  }
}
