import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Rol } from '../comun/rol.enum';
import { verificarClave } from '../dominio/clave';
import { Usuario } from './usuario.entity';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(Usuario) private readonly usuarios: Repository<Usuario>,
    private readonly jwt: JwtService,
  ) {}

  async login(email: string, clave: string) {
    const usuario = await this.usuarios
      .createQueryBuilder('u')
      .addSelect('u.passwordHash')
      .where('lower(u.email) = lower(:email) AND u.activo = true', { email })
      .getOne();

    // El mismo mensaje para usuario inexistente y clave errada: no revela qué falló
    if (!usuario || !verificarClave(clave, usuario.passwordHash)) {
      throw new UnauthorizedException('Credenciales incorrectas');
    }

    const nombre = `${usuario.nombres} ${usuario.apellidos}`;
    const token = await this.jwt.signAsync({ sub: usuario.id, rol: usuario.rol, nombre });
    return { token, usuario: { id: usuario.id, nombre, rol: usuario.rol } };
  }

  listarOperarios() {
    return this.usuarios.find({
      where: { rol: Rol.OPERARIO, activo: true },
      order: { apellidos: 'ASC' },
    });
  }
}
