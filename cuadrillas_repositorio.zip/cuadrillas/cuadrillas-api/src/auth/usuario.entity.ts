import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { Rol } from '../comun/rol.enum';

@Entity('usuario')
export class Usuario {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() identificacion: string;
  @Column() nombres: string;
  @Column() apellidos: string;
  @Column() email: string;
  @Column({ name: 'password_hash', select: false }) passwordHash: string;
  @Column({ type: 'enum', enum: Rol, enumName: 'rol_usuario' }) rol: Rol;
  @Column({ default: true }) activo: boolean;
}
