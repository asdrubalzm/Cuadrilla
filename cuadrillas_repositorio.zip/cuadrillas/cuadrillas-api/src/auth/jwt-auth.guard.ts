import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/** Rechaza con 401 toda petición sin un token válido y vigente. */
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
