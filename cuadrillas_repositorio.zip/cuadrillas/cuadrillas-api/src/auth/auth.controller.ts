import { Body, Controller, Get, HttpCode, Post, UseGuards } from '@nestjs/common';
import { Rol } from '../comun/rol.enum';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { LoginDto } from './login.dto';
import { Roles, RolesGuard } from './roles.guard';

@Controller()
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Post('auth/login')
  @HttpCode(200)
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto.email, dto.clave);
  }

  /** Operarios activos, para que el supervisor elija a quién asignar. */
  @Get('usuarios/operarios')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Rol.SUPERVISOR, Rol.GERENTE)
  async operarios() {
    const lista = await this.auth.listarOperarios();
    return lista.map((u) => ({ id: u.id, nombre: `${u.nombres} ${u.apellidos}` }));
  }
}
