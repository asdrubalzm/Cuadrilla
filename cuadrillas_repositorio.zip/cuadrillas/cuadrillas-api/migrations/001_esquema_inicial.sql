-- Esquema inicial del servidor (PostgreSQL 16)
-- Dieciséis tablas: personas y organización, planificación, ejecución, inventario y sincronización.

CREATE TYPE rol_usuario AS ENUM ('OPERARIO', 'SUPERVISOR', 'GERENTE');

CREATE TYPE estado_orden AS ENUM (
  'PLANIFICADA', 'ASIGNADA', 'EN_PREPARACION', 'EN_EJECUCION', 'BLOQUEADA',
  'FINALIZADA', 'EN_REVISION', 'APROBADA', 'RECHAZADA', 'CANCELADA');

-- ---------------------------------------------------------------- personas y organización
CREATE TABLE usuario (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identificacion  text NOT NULL UNIQUE,
  nombres         text NOT NULL,
  apellidos       text NOT NULL,
  email           text NOT NULL UNIQUE,
  password_hash   text NOT NULL,
  rol             rol_usuario NOT NULL,
  activo          boolean NOT NULL DEFAULT true
);

CREATE TABLE cuadrilla (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supervisor_id  uuid NOT NULL REFERENCES usuario(id),
  nombre         text NOT NULL UNIQUE,
  activa         boolean NOT NULL DEFAULT true
);

CREATE TABLE cuadrilla_miembro (
  cuadrilla_id  uuid NOT NULL REFERENCES cuadrilla(id),
  operario_id   uuid NOT NULL REFERENCES usuario(id),
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  PRIMARY KEY (cuadrilla_id, operario_id),
  CHECK (hasta IS NULL OR hasta >= desde)
);

CREATE TABLE edificio (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre            text NOT NULL UNIQUE,
  cliente           text NOT NULL,
  direccion         text NOT NULL,
  latitud           double precision NOT NULL,
  longitud          double precision NOT NULL,
  radio_geocerca_m  integer NOT NULL DEFAULT 150 CHECK (radio_geocerca_m > 0)
);

CREATE TABLE zona (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  edificio_id          uuid NOT NULL REFERENCES edificio(id),
  nombre               text NOT NULL,
  piso                 integer NOT NULL,
  tipo                 text NOT NULL CHECK (tipo IN ('INTERIOR', 'FACHADA', 'SUBSUELO')),
  superficie_m2        numeric(8,2) NOT NULL CHECK (superficie_m2 > 0),
  requiere_epp_altura  boolean NOT NULL DEFAULT false,  -- trabajo en altura: escalera, plataforma o fachada
  UNIQUE (edificio_id, nombre)
);

CREATE TABLE sla (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  edificio_id     uuid NOT NULL REFERENCES edificio(id),
  frecuencia      text NOT NULL CHECK (frecuencia IN ('DIARIA', 'SEMANAL', 'MENSUAL')),
  hora_limite     time NOT NULL,
  tolerancia_min  integer NOT NULL DEFAULT 0 CHECK (tolerancia_min >= 0)
);

-- ---------------------------------------------------------------- planificación
CREATE TABLE sprint (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cuadrilla_id  uuid NOT NULL REFERENCES cuadrilla(id),
  fecha_inicio  date NOT NULL,
  fecha_fin     date NOT NULL,
  objetivo      text NOT NULL,
  estado        text NOT NULL DEFAULT 'ABIERTO' CHECK (estado IN ('ABIERTO', 'CERRADO')),
  CHECK (fecha_fin >= fecha_inicio)
);

CREATE TABLE orden_trabajo (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sprint_id     uuid NOT NULL REFERENCES sprint(id),
  zona_id       uuid NOT NULL REFERENCES zona(id),
  operario_id   uuid REFERENCES usuario(id),
  sla_id        uuid REFERENCES sla(id),
  estado        estado_orden NOT NULL DEFAULT 'PLANIFICADA',
  prioridad     smallint NOT NULL DEFAULT 2 CHECK (prioridad BETWEEN 1 AND 3),
  inicio_plan   timestamptz NOT NULL,
  fin_plan      timestamptz NOT NULL,
  inicio_real   timestamptz,
  fin_real      timestamptz,
  nivel_alerta  smallint NOT NULL DEFAULT 0,
  version       integer NOT NULL DEFAULT 1,
  CHECK (fin_plan > inicio_plan),
  CHECK (fin_real IS NULL OR inicio_real IS NOT NULL)
);
CREATE INDEX idx_orden_operario_estado ON orden_trabajo (operario_id, estado);
CREATE INDEX idx_orden_sprint ON orden_trabajo (sprint_id);

-- ---------------------------------------------------------------- ejecución
CREATE TABLE checklist_seguridad (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orden_id       uuid NOT NULL REFERENCES orden_trabajo(id),
  items          jsonb NOT NULL,
  aprobado       boolean NOT NULL,
  confirmado_en  timestamptz NOT NULL
);

CREATE TABLE evidencia (
  id                 uuid PRIMARY KEY,           -- lo genera el teléfono
  orden_id           uuid NOT NULL REFERENCES orden_trabajo(id),
  tipo               text NOT NULL CHECK (tipo IN ('ANTES', 'DESPUES', 'INCIDENTE')),
  ruta_archivo       text,
  hash_sha256        char(64) NOT NULL,
  latitud            double precision,
  longitud           double precision,
  precision_m        double precision,
  capturado_en       timestamptz NOT NULL,
  recibido_en        timestamptz NOT NULL DEFAULT now(),
  archivo_recibido   boolean NOT NULL DEFAULT false,
  fuera_de_geocerca  boolean NOT NULL DEFAULT false   -- RN3: se acepta, pero se revisa
);
CREATE INDEX idx_evidencia_orden ON evidencia (orden_id);

CREATE TABLE impedimento (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orden_id      uuid NOT NULL REFERENCES orden_trabajo(id),
  tipo          text NOT NULL CHECK (tipo IN ('INSUMO', 'EPP', 'CLIMA', 'ACCESO', 'OTRO')),
  descripcion   text NOT NULL,
  estado        text NOT NULL DEFAULT 'ABIERTO' CHECK (estado IN ('ABIERTO', 'RESUELTO')),
  reportado_en  timestamptz NOT NULL,
  resuelto_en   timestamptz
);

CREATE TABLE evaluacion_calidad (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orden_id       uuid NOT NULL REFERENCES orden_trabajo(id),
  supervisor_id  uuid NOT NULL REFERENCES usuario(id),
  resultado      text NOT NULL CHECK (resultado IN ('CONFORME', 'NO_CONFORME')),
  puntaje        smallint NOT NULL CHECK (puntaje BETWEEN 1 AND 5),
  comentario     text,
  evaluado_en    timestamptz NOT NULL DEFAULT now(),
  CHECK (resultado = 'CONFORME' OR length(trim(coalesce(comentario, ''))) > 0)  -- RN5
);

-- ---------------------------------------------------------------- inventario
CREATE TABLE insumo (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre             text NOT NULL UNIQUE,
  unidad             text NOT NULL DEFAULT 'ml',
  rendimiento_ml_m2  numeric(8,2)  NOT NULL CHECK (rendimiento_ml_m2 > 0),
  stock_actual       numeric(12,2) NOT NULL DEFAULT 0 CHECK (stock_actual >= 0),
  stock_minimo       numeric(12,2) NOT NULL DEFAULT 0,
  costo_unitario     numeric(10,4) NOT NULL DEFAULT 0
);

CREATE TABLE consumo_insumo (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orden_id          uuid NOT NULL REFERENCES orden_trabajo(id),
  insumo_id         uuid NOT NULL REFERENCES insumo(id),
  cantidad_teorica  numeric(12,2) NOT NULL CHECK (cantidad_teorica >= 0),
  cantidad_real     numeric(12,2) NOT NULL CHECK (cantidad_real >= 0)
);

CREATE TABLE movimiento_inventario (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  insumo_id   uuid NOT NULL REFERENCES insumo(id),
  orden_id    uuid REFERENCES orden_trabajo(id),
  usuario_id  uuid NOT NULL REFERENCES usuario(id),
  tipo        text NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA', 'AJUSTE')),
  cantidad    numeric(12,2) NOT NULL CHECK (cantidad > 0),
  fecha       timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- sincronización
CREATE TABLE sync_operacion (
  operacion_uuid  uuid PRIMARY KEY,  -- lo genera el teléfono: garantiza idempotencia
  usuario_id      uuid NOT NULL REFERENCES usuario(id),
  dispositivo_id  text NOT NULL,
  entidad         text NOT NULL,
  accion          text NOT NULL,
  resultado       text NOT NULL,
  recibido_en     timestamptz NOT NULL DEFAULT now()
);
