-- ESCENARIO SIMULADO DE VALIDACIÓN
-- Todos los datos de este archivo son ficticios: el edificio, el cliente, las personas,
-- las superficies, los insumos y sus costos se crearon para probar el prototipo en un
-- entorno controlado. No provienen de ninguna empresa.
--
-- Contraseña de todos los usuarios de demostración: Demo2026*

INSERT INTO usuario (identificacion, nombres, apellidos, email, password_hash, rol) VALUES
  ('SIM-0001', 'Laura',  'Méndez', 'gerente@demo.local',    'scrypt$63756164726c6c61732d64656d6f3236$896be42700e0b7469c39cf7f03e125e8c8a9b4a2b424845bd340459975701a9d', 'GERENTE'),
  ('SIM-0002', 'Carlos', 'Rivas',  'supervisor@demo.local', 'scrypt$63756164726c6c61732d64656d6f3236$896be42700e0b7469c39cf7f03e125e8c8a9b4a2b424845bd340459975701a9d', 'SUPERVISOR'),
  ('SIM-0101', 'Ana',    'Torres', 'ana@demo.local',        'scrypt$63756164726c6c61732d64656d6f3236$896be42700e0b7469c39cf7f03e125e8c8a9b4a2b424845bd340459975701a9d', 'OPERARIO'),
  ('SIM-0102', 'Luis',   'Peña',   'luis@demo.local',       'scrypt$63756164726c6c61732d64656d6f3236$896be42700e0b7469c39cf7f03e125e8c8a9b4a2b424845bd340459975701a9d', 'OPERARIO'),
  ('SIM-0103', 'Marta',  'Solís',  'marta@demo.local',      'scrypt$63756164726c6c61732d64656d6f3236$896be42700e0b7469c39cf7f03e125e8c8a9b4a2b424845bd340459975701a9d', 'OPERARIO');

INSERT INTO cuadrilla (supervisor_id, nombre)
SELECT id, 'Cuadrilla Vidrios A' FROM usuario WHERE email = 'supervisor@demo.local';

INSERT INTO cuadrilla_miembro (cuadrilla_id, operario_id)
SELECT c.id, u.id FROM cuadrilla c, usuario u WHERE u.rol = 'OPERARIO';

-- Edificio ficticio de oficinas (servicio de limpieza de vidrios interiores); las coordenadas corresponden a un punto genérico de Midtown, Nueva York.
INSERT INTO edificio (nombre, cliente, direccion, latitud, longitud, radio_geocerca_m) VALUES
  ('Torre Hudson (simulada)', 'Cliente corporativo de demostración',
   'Midtown Manhattan, Nueva York (dirección ficticia)', 40.7540, -73.9840, 150);

INSERT INTO sla (edificio_id, frecuencia, hora_limite, tolerancia_min)
SELECT id, 'DIARIA',  time '11:00', 15 FROM edificio
UNION ALL
SELECT id, 'SEMANAL', time '16:00', 30 FROM edificio;

-- 18 zonas interiores: 11 a nivel de piso, 3 con paños altos (trabajo sobre escalera)
-- y 4 de subsuelo (sin cobertura de datos)
INSERT INTO zona (edificio_id, nombre, piso, tipo, superficie_m2, requiere_epp_altura)
SELECT e.id, z.nombre, z.piso, z.tipo, z.m2, z.altura
FROM edificio e, (VALUES
  ('Vestíbulo principal',                      1, 'INTERIOR', 120.00, false),
  ('Puertas giratorias y acceso',              1, 'INTERIOR',  45.00, false),
  ('Vestíbulo, paños altos',                   1, 'INTERIOR',  90.00, true),
  ('Pasamanos de vidrio, escalera principal',  2, 'INTERIOR',  55.00, false),
  ('Mamparas piso 5',                          5, 'INTERIOR',  85.00, false),
  ('Mamparas piso 8',                          8, 'INTERIOR',  85.00, false),
  ('Mamparas piso 10',                        10, 'INTERIOR',  85.00, false),
  ('Salas de reuniones piso 12',              12, 'INTERIOR',  60.00, false),
  ('Atrio piso 15',                           15, 'INTERIOR', 140.00, false),
  ('Atrio piso 15, paños altos',              15, 'INTERIOR', 110.00, true),
  ('Mamparas piso 17',                        17, 'INTERIOR',  85.00, false),
  ('Mamparas piso 20',                        20, 'INTERIOR',  85.00, false),
  ('Comedor piso 22',                         22, 'INTERIOR',  70.00, false),
  ('Comedor piso 22, ventanales altos',       22, 'INTERIOR',  60.00, true),
  ('Subsuelo 1, acceso vehicular',            -1, 'SUBSUELO',  40.00, false),
  ('Subsuelo 1, garita y oficinas',           -1, 'SUBSUELO',  35.00, false),
  ('Subsuelo 2, ascensores',                  -2, 'SUBSUELO',  30.00, false),
  ('Subsuelo 2, cuarto de control',           -2, 'SUBSUELO',  25.00, false)
) AS z(nombre, piso, tipo, m2, altura);

-- Insumos líquidos (rendimiento en ml por m²); existencias y costos simulados
INSERT INTO insumo (nombre, unidad, rendimiento_ml_m2, stock_actual, stock_minimo, costo_unitario) VALUES
  ('Limpiavidrios diluido',   'ml', 15.00, 40000, 8000, 0.0040),
  ('Desengrasante neutro',    'ml',  8.00, 20000, 4000, 0.0060);

INSERT INTO movimiento_inventario (insumo_id, usuario_id, tipo, cantidad)
SELECT i.id, u.id, 'ENTRADA', i.stock_actual FROM insumo i, usuario u WHERE u.email = 'gerente@demo.local';

-- Sprint de dos semanas que empieza el lunes de la semana en curso
INSERT INTO sprint (cuadrilla_id, fecha_inicio, fecha_fin, objetivo)
SELECT id, date_trunc('week', CURRENT_DATE)::date, (date_trunc('week', CURRENT_DATE) + interval '13 days')::date,
       'Cubrir las 18 zonas del edificio dentro del SLA y sin paralizaciones por insumos'
FROM cuadrilla;

-- 18 órdenes para la jornada de hoy, sin asignar. Las zonas a nivel de piso y los subsuelos
-- vencen a las 11:00 (SLA diario); los paños altos, a las 16:00 (SLA semanal). Hora de Nueva York.
INSERT INTO orden_trabajo (sprint_id, zona_id, sla_id, prioridad, inicio_plan, fin_plan)
SELECT s.id, z.id, a.id,
       CASE WHEN z.requiere_epp_altura THEN 1 WHEN z.tipo = 'SUBSUELO' THEN 3 ELSE 2 END,
       (CURRENT_DATE + time '07:00') AT TIME ZONE 'America/New_York',
       (CURRENT_DATE + a.hora_limite) AT TIME ZONE 'America/New_York'
FROM sprint s, zona z
JOIN sla a ON a.edificio_id = z.edificio_id
          AND a.frecuencia = CASE WHEN z.requiere_epp_altura THEN 'SEMANAL' ELSE 'DIARIA' END;
