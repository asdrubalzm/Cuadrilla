// Pruebas unitarias del cliente. Se ejecutan con:  flutter test
import 'package:cuadrillas_app/data/modelos/evidencia.dart';
import 'package:cuadrillas_app/data/modelos/insumo.dart';
import 'package:cuadrillas_app/data/modelos/orden_trabajo.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('OrdenTrabajo', () {
    final orden = OrdenTrabajo(
      id: '11111111-1111-4111-8111-111111111111',
      zonaNombre: 'Vestíbulo principal',
      superficieM2: 120,
      requiereEppAltura: false,
      finPlan: DateTime.utc(2026, 11, 16, 16),
    );

    test('se guarda y se recupera de SQLite sin perder datos', () {
      final copia = OrdenTrabajo.fromMap(orden.toMap());
      expect(copia.id, orden.id);
      expect(copia.zonaNombre, 'Vestíbulo principal');
      expect(copia.superficieM2, 120);
      expect(copia.requiereEppAltura, isFalse);
      expect(copia.finPlan, orden.finPlan);
      expect(copia.estado, EstadoOrden.asignada);
      expect(copia.inicioReal, isNull);
    });

    test('los valores lógicos se guardan como 0 y 1', () {
      expect(orden.toMap()['requiere_epp_altura'], 0);
    });

    test('convierte los estados del servidor a los del teléfono', () {
      Map<String, dynamic> respuesta(String estado) => {
            'id': orden.id,
            'zonaNombre': 'Atrio piso 15, paños altos',
            'superficieM2': 240,
            'requiereEppAltura': true,
            'finPlan': '2026-11-16T21:00:00.000Z',
            'estado': estado,
            'inicioReal': null,
          };
      expect(ordenDesdeApi(respuesta('ASIGNADA')).estado, EstadoOrden.asignada);
      expect(ordenDesdeApi(respuesta('EN_PREPARACION')).estado, EstadoOrden.enPreparacion);
      expect(ordenDesdeApi(respuesta('EN_EJECUCION')).estado, EstadoOrden.enEjecucion);
      expect(ordenDesdeApi(respuesta('BLOQUEADA')).estado, EstadoOrden.bloqueada);
      expect(ordenDesdeApi(respuesta('ASIGNADA')).requiereEppAltura, isTrue);
    });
  });

  group('Insumo (RN4)', () {
    const limpiavidrios = Insumo(id: 'i1', nombre: 'Limpiavidrios diluido', rendimientoMlM2: 15);

    test('120 m² con 15 ml/m² dan 1 800 ml', () {
      expect(limpiavidrios.consumoTeorico(120), 1800);
    });

    test('redondea a dos decimales', () {
      const otro = Insumo(id: 'i2', nombre: 'Prueba', rendimientoMlM2: 8.33);
      expect(otro.consumoTeorico(42.5), 354.03);
    });
  });

  group('Evidencia', () {
    final foto = Evidencia(
      id: '22222222-2222-4222-8222-222222222222',
      ordenId: '11111111-1111-4111-8111-111111111111',
      tipo: 'DESPUES',
      ruta: '/data/user/0/app/cache/foto.jpg',
      hashSha256: 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
      latitud: 40.7541,
      longitud: -73.9841,
      precisionM: 12,
      capturadoEn: DateTime.utc(2026, 11, 16, 15, 30),
    );

    test('lo que viaja al servidor no incluye la ruta del teléfono', () {
      final json = foto.toJson();
      expect(json.containsKey('ruta'), isFalse);
      expect(json['hashSha256'], foto.hashSha256);
      expect(json['capturadoEn'], '2026-11-16T15:30:00.000Z');
    });

    test('la fila local nace como pendiente de subir', () {
      expect(foto.toMap()['subida'], 0);
    });
  });
}
