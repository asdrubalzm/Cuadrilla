class Evidencia {
  const Evidencia({
    required this.id,
    required this.ordenId,
    required this.tipo,
    required this.ruta,
    required this.hashSha256,
    required this.capturadoEn,
    this.latitud,
    this.longitud,
    this.precisionM,
  });

  final String id;         // UUID generado en el teléfono
  final String ordenId;
  final String tipo;       // ANTES, DESPUES o INCIDENTE
  final String ruta;       // archivo en el teléfono
  final String hashSha256; // huella de los bytes de la fotografía
  final double? latitud;
  final double? longitud;
  final double? precisionM;
  final DateTime capturadoEn;

  /// Fila de la tabla local `evidencia`. `subida`: 0 pendiente, 1 enviada, 2 rechazada.
  Map<String, Object?> toMap() => {
        'id': id,
        'orden_id': ordenId,
        'tipo': tipo,
        'ruta': ruta,
        'hash_sha256': hashSha256,
        'latitud': latitud,
        'longitud': longitud,
        'precision_m': precisionM,
        'capturado_en': capturadoEn.toIso8601String(),
        'subida': 0,
      };

  /// Metadatos que viajan al servidor junto con el cierre de la orden.
  /// La ruta local no se envía: el archivo se sube aparte.
  Map<String, Object?> toJson() => {
        'id': id,
        'tipo': tipo,
        'hashSha256': hashSha256,
        'latitud': latitud,
        'longitud': longitud,
        'precisionM': precisionM,
        'capturadoEn': capturadoEn.toIso8601String(),
      };
}
