enum EstadoOrden { asignada, enPreparacion, enEjecucion, bloqueada, finalizada }

class OrdenTrabajo {
  final String id;               // UUID asignado por el servidor
  final String zonaNombre;
  final double superficieM2;     // base del cálculo de consumo teórico
  final bool requiereEppAltura;  // trabajo en altura: añade los ítems de la escalera
  final DateTime finPlan;        // límite frente al SLA
  EstadoOrden estado;
  DateTime? inicioReal;
  DateTime? finReal;

  OrdenTrabajo({
    required this.id,
    required this.zonaNombre,
    required this.superficieM2,
    required this.requiereEppAltura,
    required this.finPlan,
    this.estado = EstadoOrden.asignada,
    this.inicioReal,
    this.finReal,
  });

  factory OrdenTrabajo.fromMap(Map<String, Object?> m) => OrdenTrabajo(
        id: m['id'] as String,
        zonaNombre: m['zona_nombre'] as String,
        superficieM2: (m['superficie_m2'] as num).toDouble(),
        requiereEppAltura: m['requiere_epp_altura'] == 1,
        finPlan: DateTime.parse(m['fin_plan'] as String),
        estado: EstadoOrden.values.byName(m['estado'] as String),
        inicioReal: _fecha(m['inicio_real']),
        finReal: _fecha(m['fin_real']),
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'zona_nombre': zonaNombre,
        'superficie_m2': superficieM2,
        'requiere_epp_altura': requiereEppAltura ? 1 : 0,
        'fin_plan': finPlan.toIso8601String(),
        'estado': estado.name,
        'inicio_real': inicioReal?.toIso8601String(),
        'fin_real': finReal?.toIso8601String(),
      };

  static DateTime? _fecha(Object? v) =>
      v == null ? null : DateTime.parse(v as String);
}

/// Convierte una orden de la respuesta de GET /ordenes/mias al modelo del teléfono.
/// El servidor maneja diez estados; al teléfono solo llegan los cuatro abiertos.
OrdenTrabajo ordenDesdeApi(Map<String, dynamic> j) => OrdenTrabajo(
      id: j['id'] as String,
      zonaNombre: j['zonaNombre'] as String,
      superficieM2: (j['superficieM2'] as num).toDouble(),
      requiereEppAltura: j['requiereEppAltura'] as bool,
      finPlan: DateTime.parse(j['finPlan'] as String),
      estado: switch (j['estado'] as String) {
        'EN_PREPARACION' => EstadoOrden.enPreparacion,
        'EN_EJECUCION' => EstadoOrden.enEjecucion,
        'BLOQUEADA' => EstadoOrden.bloqueada,
        _ => EstadoOrden.asignada,
      },
      inicioReal: OrdenTrabajo._fecha(j['inicioReal']),
    );
