class Insumo {
  const Insumo({required this.id, required this.nombre, required this.rendimientoMlM2});

  final String id;
  final String nombre;
  final double rendimientoMlM2; // mililitros por metro cuadrado

  /// RN4: consumo teórico = superficie (m²) × rendimiento (ml/m²), a dos decimales.
  double consumoTeorico(double superficieM2) =>
      (superficieM2 * rendimientoMlM2 * 100).roundToDouble() / 100;

  factory Insumo.fromApi(Map<String, dynamic> j) => Insumo(
        id: j['id'] as String,
        nombre: j['nombre'] as String,
        rendimientoMlM2: (j['rendimientoMlM2'] as num).toDouble(),
      );

  factory Insumo.fromMap(Map<String, Object?> m) => Insumo(
        id: m['id'] as String,
        nombre: m['nombre'] as String,
        rendimientoMlM2: (m['rendimiento_ml_m2'] as num).toDouble(),
      );

  Map<String, Object?> toMap() =>
      {'id': id, 'nombre': nombre, 'rendimiento_ml_m2': rendimientoMlM2};
}
