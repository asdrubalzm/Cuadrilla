import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import '../local_db.dart';
import '../modelos/evidencia.dart';
import '../modelos/insumo.dart';
import '../modelos/orden_trabajo.dart';

/// Único punto de acceso a las órdenes en el teléfono. Las pantallas nunca llaman a la
/// API para ejecutar una orden: escriben en SQLite y dejan la operación en la cola.
class OrdenRepository {
  OrdenRepository(this._api);
  final Dio _api;
  final _uuid = const Uuid();

  // ---------------------------------------------------------------- lectura local

  Future<List<OrdenTrabajo>> listar() async {
    final db = await LocalDb.instancia;
    final filas = await db.query('orden', orderBy: 'fin_plan, zona_nombre');
    return [for (final f in filas) OrdenTrabajo.fromMap(f)];
  }

  Future<List<Insumo>> insumos() async {
    final db = await LocalDb.instancia;
    final filas = await db.query('insumo', orderBy: 'nombre');
    return [for (final f in filas) Insumo.fromMap(f)];
  }

  /// Operaciones y fotografías que todavía no llegan al servidor.
  Future<int> pendientes() async {
    final db = await LocalDb.instancia;
    final ops = Sqflite.firstIntValue(await db
            .rawQuery("SELECT COUNT(*) FROM cola_sync WHERE estado = 'PENDIENTE'")) ??
        0;
    final fotos = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM evidencia WHERE subida = 0')) ??
        0;
    return ops + fotos;
  }

  /// Operaciones que el servidor rechazó, con su motivo, para mostrarlas al operario.
  Future<List<Map<String, Object?>>> rechazadas() async {
    final db = await LocalDb.instancia;
    return db.query('cola_sync',
        columns: ['accion', 'ultimo_error', 'creado_en'],
        where: "estado = 'RECHAZADA'",
        orderBy: 'creado_en DESC',
        limit: 10);
  }

  // ---------------------------------------------------------------- descarga (requiere red)

  /// Trae las órdenes abiertas del operario y el catálogo de insumos (RF07).
  /// RN7: no pisa las órdenes que tienen operaciones locales sin enviar.
  Future<void> descargar() async {
    final resp = await _api.get('/ordenes/mias');
    final datos = Map<String, dynamic>.from(resp.data as Map);
    final ordenes = [
      for (final j in datos['ordenes'] as List)
        ordenDesdeApi(Map<String, dynamic>.from(j as Map))
    ];
    final catalogo = [
      for (final j in datos['insumos'] as List)
        Insumo.fromApi(Map<String, dynamic>.from(j as Map))
    ];

    final db = await LocalDb.instancia;
    await db.transaction((txn) async {
      final cola = await txn.query('cola_sync',
          columns: ['payload'], where: "estado = 'PENDIENTE'");
      final conCambiosLocales = {
        for (final op in cola)
          (jsonDecode(op['payload'] as String) as Map)['ordenId'] as String
      };
      final idsServidor = {for (final o in ordenes) o.id};

      // Órdenes que el servidor ya no lista (reasignadas, en revisión o aprobadas)
      for (final fila in await txn.query('orden', columns: ['id'])) {
        final id = fila['id'] as String;
        if (idsServidor.contains(id) || conCambiosLocales.contains(id)) continue;
        final fotosSinSubir = Sqflite.firstIntValue(await txn.rawQuery(
                'SELECT COUNT(*) FROM evidencia WHERE orden_id = ? AND subida = 0',
                [id])) ??
            0;
        if (fotosSinSubir > 0) continue; // se conserva hasta que suba su fotografía
        await txn.delete('evidencia', where: 'orden_id = ?', whereArgs: [id]);
        await txn.delete('orden', where: 'id = ?', whereArgs: [id]);
      }

      for (final orden in ordenes) {
        if (conCambiosLocales.contains(orden.id)) continue;
        final actualizadas = await txn
            .update('orden', orden.toMap(), where: 'id = ?', whereArgs: [orden.id]);
        if (actualizadas == 0) await txn.insert('orden', orden.toMap());
      }

      await txn.delete('insumo');
      for (final insumo in catalogo) {
        await txn.insert('insumo', insumo.toMap());
      }
    });
  }

  // ---------------------------------------------------------------- escritura local (con o sin red)

  /// Registra la lista de seguridad y el inicio de la rutina (RF08, RF09).
  Future<void> iniciarOrden(OrdenTrabajo orden, Map<String, bool> checklist) async {
    final db = await LocalDb.instancia;
    final ahora = DateTime.now().toUtc().toIso8601String();

    await db.transaction((txn) async {
      final filas = await txn.update(
        'orden',
        {'estado': EstadoOrden.enEjecucion.name, 'inicio_real': ahora},
        where: 'id = ? AND estado IN (?, ?)',
        whereArgs: [
          orden.id,
          EstadoOrden.asignada.name,
          EstadoOrden.enPreparacion.name,
        ],
      );
      if (filas == 0) throw StateError('La orden no está lista para iniciar');

      await txn.insert('cola_sync', {
        'operacion_uuid': _uuid.v4(),
        'entidad': 'orden',
        'accion': 'INICIAR',
        'payload': jsonEncode({
          'ordenId': orden.id,
          'inicioReal': ahora,
          'checklist': checklist,
        }),
        'creado_en': ahora,
      });
    });
    orden
      ..estado = EstadoOrden.enEjecucion
      ..inicioReal = DateTime.parse(ahora);
  }

  /// Cierra la orden en el teléfono. Funciona igual con o sin conexión.
  Future<void> finalizarOrden(
      OrdenTrabajo orden, Evidencia foto, Map<String, double> consumoReal) async {
    final db = await LocalDb.instancia;
    final ahora = DateTime.now().toUtc().toIso8601String();

    await db.transaction((txn) async {
      final filas = await txn.update(
        'orden',
        {'estado': EstadoOrden.finalizada.name, 'fin_real': ahora},
        where: 'id = ? AND estado = ?',
        whereArgs: [orden.id, EstadoOrden.enEjecucion.name],
      );
      if (filas == 0) throw StateError('La orden no está en ejecución');

      await txn.insert('evidencia', foto.toMap());
      await txn.insert('cola_sync', {
        'operacion_uuid': _uuid.v4(),
        'entidad': 'orden',
        'accion': 'FINALIZAR',
        'payload': jsonEncode({
          'ordenId': orden.id,
          'finReal': ahora,
          'evidencia': foto.toJson(),
          'consumoReal': consumoReal, // idInsumo -> mililitros usados
        }),
        'creado_en': ahora,
      });
    });
  }

  /// Reporta un impedimento y deja la orden bloqueada hasta que el supervisor decida (RF11).
  Future<void> reportarImpedimento(
      OrdenTrabajo orden, String tipo, String descripcion) async {
    final db = await LocalDb.instancia;
    final ahora = DateTime.now().toUtc().toIso8601String();

    await db.transaction((txn) async {
      final filas = await txn.update(
        'orden',
        {'estado': EstadoOrden.bloqueada.name},
        where: 'id = ? AND estado IN (?, ?, ?)',
        whereArgs: [
          orden.id,
          EstadoOrden.asignada.name,
          EstadoOrden.enPreparacion.name,
          EstadoOrden.enEjecucion.name,
        ],
      );
      if (filas == 0) throw StateError('La orden no admite un impedimento');

      await txn.insert('cola_sync', {
        'operacion_uuid': _uuid.v4(),
        'entidad': 'orden',
        'accion': 'BLOQUEAR',
        'payload': jsonEncode({
          'ordenId': orden.id,
          'tipo': tipo,
          'descripcion': descripcion,
          'reportadoEn': ahora,
        }),
        'creado_en': ahora,
      });
    });
    orden.estado = EstadoOrden.bloqueada;
  }
}
