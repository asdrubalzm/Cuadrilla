import 'package:dio/dio.dart';

/// Existencias e ingresos de insumos, para el panel del supervisor (RF14, RF15).
class InventarioRepository {
  InventarioRepository(this._api);
  final Dio _api;

  Future<List<Map<String, dynamic>>> insumos() async {
    final resp = await _api.get('/inventario/insumos');
    return [for (final j in resp.data as List) Map<String, dynamic>.from(j as Map)];
  }

  /// tipo: ENTRADA suma la cantidad; AJUSTE fija las existencias en la cantidad contada.
  Future<void> registrarMovimiento(String insumoId, String tipo, double cantidad) =>
      _api.post('/inventario/movimientos',
          data: {'insumoId': insumoId, 'tipo': tipo, 'cantidad': cantidad});
}
