import 'dart:typed_data';

import 'package:dio/dio.dart';

/// Llamadas a la API que usa el panel web. El panel trabaja siempre en línea.
class PanelRepository {
  PanelRepository(this._api);
  final Dio _api;

  List<Map<String, dynamic>> _lista(dynamic datos) =>
      [for (final j in datos as List) Map<String, dynamic>.from(j as Map)];

  Future<List<Map<String, dynamic>>> sprints() async =>
      _lista((await _api.get('/sprints')).data);

  Future<List<Map<String, dynamic>>> operarios() async =>
      _lista((await _api.get('/usuarios/operarios')).data);

  Future<List<Map<String, dynamic>>> ordenes(String sprintId, {String? estado}) async =>
      _lista((await _api.get('/ordenes', queryParameters: {
        'sprintId': sprintId,
        if (estado != null) 'estado': estado,
      }))
          .data);

  Future<void> asignar(String ordenId, String operarioId) =>
      _api.post('/ordenes/$ordenId/asignar', data: {'operarioId': operarioId});

  Future<void> desbloquear(String ordenId) => _api.post('/ordenes/$ordenId/desbloqueo');

  Future<Map<String, dynamic>> detalle(String ordenId) async =>
      Map<String, dynamic>.from((await _api.get('/ordenes/$ordenId')).data as Map);

  Future<void> evaluar(String ordenId,
          {required bool conforme, required int puntaje, String? comentario}) =>
      _api.post('/ordenes/$ordenId/evaluacion', data: {
        'conforme': conforme,
        'puntaje': puntaje,
        if (comentario != null && comentario.trim().isNotEmpty) 'comentario': comentario,
      });

  /// La fotografía se pide con el token; por eso no se usa una URL directa en la imagen.
  Future<Uint8List> fotografia(String evidenciaId) async {
    final resp = await _api.get<List<int>>('/evidencias/$evidenciaId/archivo',
        options: Options(responseType: ResponseType.bytes));
    return Uint8List.fromList(resp.data ?? const []);
  }

  Future<Map<String, dynamic>> tablero(String sprintId) async =>
      Map<String, dynamic>.from((await _api.get('/tablero/sprints/$sprintId')).data as Map);

  Future<Map<String, dynamic>> reporteSla() async =>
      Map<String, dynamic>.from((await _api.get('/reportes/sla')).data as Map);
}
