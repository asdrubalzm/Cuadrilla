import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class LocalDb {
  static Database? _db;

  static Future<Database> get instancia async => _db ??= await openDatabase(
        join(await getDatabasesPath(), 'cuadrillas.db'),
        version: 1,
        onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
        onCreate: (db, _) async {
          await db.execute('''CREATE TABLE orden(
            id TEXT PRIMARY KEY, zona_nombre TEXT NOT NULL,
            superficie_m2 REAL NOT NULL, requiere_epp_altura INTEGER NOT NULL,
            fin_plan TEXT NOT NULL, estado TEXT NOT NULL,
            inicio_real TEXT, fin_real TEXT)''');
          await db.execute('''CREATE TABLE evidencia(
            id TEXT PRIMARY KEY, orden_id TEXT NOT NULL REFERENCES orden(id),
            tipo TEXT NOT NULL, ruta TEXT NOT NULL, hash_sha256 TEXT NOT NULL,
            latitud REAL, longitud REAL, precision_m REAL,
            capturado_en TEXT NOT NULL, subida INTEGER NOT NULL DEFAULT 0)''');
          await db.execute('''CREATE TABLE cola_sync(
            operacion_uuid TEXT PRIMARY KEY, entidad TEXT NOT NULL,
            accion TEXT NOT NULL, payload TEXT NOT NULL, creado_en TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'PENDIENTE',
            intentos INTEGER NOT NULL DEFAULT 0, ultimo_error TEXT)''');
          await db.execute('''CREATE TABLE insumo(
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL,
            rendimiento_ml_m2 REAL NOT NULL)''');
        },
      );
}
