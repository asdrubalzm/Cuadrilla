import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/auth_storage.dart';
import '../data/modelos/orden_trabajo.dart';
import '../data/repositorios/orden_repository.dart';
import '../servicios/sync_service.dart';

/// Lista de órdenes del operario. Siempre se lee de la base local (RF07).
class OrdenesScreen extends StatefulWidget {
  const OrdenesScreen({super.key});

  @override
  State<OrdenesScreen> createState() => _OrdenesState();
}

class _OrdenesState extends State<OrdenesScreen> {
  List<OrdenTrabajo> _ordenes = [];
  int _pendientes = 0;
  bool _sinRed = false;
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _actualizar();
  }

  /// Envía lo pendiente, descarga las órdenes y relee la base local.
  /// Si no hay red, se muestra lo que ya está guardado en el teléfono.
  Future<void> _actualizar() async {
    final repo = context.read<OrdenRepository>();
    final sync = context.read<SyncService>();
    var sinRed = false;
    try {
      await sync.sincronizar();
      await repo.descargar();
    } catch (_) {
      sinRed = true;
    }
    final ordenes = await repo.listar();
    final pendientes = await repo.pendientes();
    if (!mounted) return;
    setState(() {
      _ordenes = ordenes;
      _pendientes = pendientes;
      _sinRed = sinRed;
      _cargando = false;
    });
  }

  Future<void> _abrir(OrdenTrabajo orden) async {
    switch (orden.estado) {
      case EstadoOrden.asignada:
      case EstadoOrden.enPreparacion:
        await Navigator.pushNamed(context, '/checklist', arguments: orden);
      case EstadoOrden.enEjecucion:
        await Navigator.pushNamed(context, '/ejecucion', arguments: orden);
      case EstadoOrden.bloqueada:
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Orden bloqueada: espere la decisión del supervisor.')));
      case EstadoOrden.finalizada:
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Orden finalizada, en espera de revisión.')));
    }
    _actualizar();
  }

  Future<void> _salir() async {
    await context.read<AuthStorage>().cerrar();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final nombre = context.read<AuthStorage>().sesion?.nombre ?? '';
    return Scaffold(
      appBar: AppBar(
        title: Text('Mis órdenes · $nombre'),
        actions: [
          IconButton(
              onPressed: _actualizar, icon: const Icon(Icons.sync), tooltip: 'Sincronizar'),
          IconButton(onPressed: _salir, icon: const Icon(Icons.logout), tooltip: 'Salir'),
        ],
      ),
      body: Column(
        children: [
          if (_sinRed || _pendientes > 0)
            MaterialBanner(
              content: Text([
                if (_sinRed) 'Sin conexión: se muestran las órdenes guardadas.',
                if (_pendientes > 0) '$_pendientes registro(s) por enviar.',
              ].join(' ')),
              leading: Icon(_sinRed ? Icons.cloud_off : Icons.cloud_upload),
              actions: [
                TextButton(onPressed: _actualizar, child: const Text('Reintentar')),
              ],
            ),
          Expanded(
            child: _cargando
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _actualizar,
                    child: _ordenes.isEmpty
                        ? ListView(children: const [
                            Padding(
                              padding: EdgeInsets.all(32),
                              child: Text('No tiene órdenes asignadas.',
                                  textAlign: TextAlign.center),
                            ),
                          ])
                        : ListView.builder(
                            itemCount: _ordenes.length,
                            itemBuilder: (_, i) => _TarjetaOrden(
                                orden: _ordenes[i], alTocar: () => _abrir(_ordenes[i])),
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _TarjetaOrden extends StatelessWidget {
  const _TarjetaOrden({required this.orden, required this.alTocar});
  final OrdenTrabajo orden;
  final VoidCallback alTocar;

  static const _etiquetas = {
    EstadoOrden.asignada: 'Asignada',
    EstadoOrden.enPreparacion: 'En preparación',
    EstadoOrden.enEjecucion: 'En ejecución',
    EstadoOrden.bloqueada: 'Bloqueada',
    EstadoOrden.finalizada: 'Finalizada',
  };

  @override
  Widget build(BuildContext context) {
    final limite = orden.finPlan.toLocal();
    final hora = '${limite.hour.toString().padLeft(2, '0')}:'
        '${limite.minute.toString().padLeft(2, '0')}';
    final vencida =
        orden.estado != EstadoOrden.finalizada && DateTime.now().isAfter(limite);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        onTap: alTocar,
        leading: Icon(orden.requiereEppAltura ? Icons.height : Icons.window, size: 32),
        title: Text(orden.zonaNombre),
        subtitle: Text(
          '${orden.superficieM2.toStringAsFixed(0)} m² · límite $hora'
          '${orden.requiereEppAltura ? ' · trabajo en altura' : ''}',
          style: vencida ? TextStyle(color: Theme.of(context).colorScheme.error) : null,
        ),
        trailing: Chip(label: Text(_etiquetas[orden.estado]!)),
      ),
    );
  }
}
