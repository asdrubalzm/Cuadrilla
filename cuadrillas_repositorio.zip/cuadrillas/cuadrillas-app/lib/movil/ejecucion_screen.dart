import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/modelos/evidencia.dart';
import '../data/modelos/insumo.dart';
import '../data/modelos/orden_trabajo.dart';
import '../data/repositorios/orden_repository.dart';
import '../servicios/evidencia_service.dart';
import '../servicios/sync_service.dart';

/// Ejecución de la rutina: fotografía final, consumo de insumos y cierre (RF09, RF10, RF13).
class EjecucionScreen extends StatefulWidget {
  const EjecucionScreen({super.key, required this.orden});
  final OrdenTrabajo orden;

  @override
  State<EjecucionScreen> createState() => _EjecucionState();
}

class _EjecucionState extends State<EjecucionScreen> {
  Evidencia? _foto;
  List<Insumo> _insumos = [];
  final Map<String, TextEditingController> _consumo = {};
  bool _guardando = false;

  @override
  void initState() {
    super.initState();
    _cargarInsumos();
  }

  @override
  void dispose() {
    for (final c in _consumo.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _cargarInsumos() async {
    final insumos = await context.read<OrdenRepository>().insumos();
    if (!mounted) return;
    setState(() {
      _insumos = insumos;
      for (final i in insumos) {
        // Se propone el consumo teórico; el operario corrige si usó otra cantidad
        _consumo[i.id] = TextEditingController(
            text: i.consumoTeorico(widget.orden.superficieM2).toStringAsFixed(0));
      }
    });
  }

  Future<void> _tomarFoto() async {
    final foto =
        await context.read<EvidenciaService>().capturar(widget.orden.id, 'DESPUES');
    if (foto != null && mounted) setState(() => _foto = foto);
  }

  Future<void> _finalizar() async {
    final foto = _foto;
    if (foto == null) return; // RN2: no se finaliza sin fotografía
    final consumoReal = <String, double>{};
    for (final i in _insumos) {
      final valor = double.tryParse(_consumo[i.id]!.text.replaceAll(',', '.'));
      if (valor == null || valor < 0) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Revise la cantidad de ${i.nombre}.')));
        return;
      }
      if (valor > 0) consumoReal[i.id] = valor;
    }

    setState(() => _guardando = true);
    final repo = context.read<OrdenRepository>();
    final sync = context.read<SyncService>();
    final mensajes = ScaffoldMessenger.of(context);
    final navegador = Navigator.of(context);
    try {
      await repo.finalizarOrden(widget.orden, foto, consumoReal);
      sync.sincronizar(); // si hay red se envía ahora; si no, cuando regrese
      mensajes.showSnackBar(const SnackBar(
          content: Text('Rutina guardada. Se enviará al supervisor al tener señal.')));
      navegador.popUntil(ModalRoute.withName('/ordenes'));
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text('No se pudo guardar: $e')));
      if (mounted) setState(() => _guardando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final orden = widget.orden;
    final foto = _foto;
    return Scaffold(
      appBar: AppBar(title: Text(orden.zonaNombre)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('${orden.superficieM2.toStringAsFixed(0)} m² de vidrio',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          if (foto == null)
            OutlinedButton.icon(
              onPressed: _tomarFoto,
              icon: const Icon(Icons.photo_camera),
              label: const Text('Tomar fotografía final'),
            )
          else ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.file(File(foto.ruta), height: 220, fit: BoxFit.cover),
            ),
            const SizedBox(height: 8),
            Text(foto.latitud == null
                ? 'Sin ubicación: la evidencia quedará marcada para revisión.'
                : 'Ubicación ${foto.latitud!.toStringAsFixed(5)}, '
                    '${foto.longitud!.toStringAsFixed(5)} '
                    '(±${foto.precisionM?.toStringAsFixed(0) ?? '?'} m)'),
            Text('Huella ${foto.hashSha256.substring(0, 16)}…',
                style: Theme.of(context).textTheme.bodySmall),
            TextButton(onPressed: _tomarFoto, child: const Text('Repetir fotografía')),
          ],
          const Divider(height: 32),
          Text('Insumos usados (ml)', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          for (final i in _insumos)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: _consumo[i.id],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: i.nombre,
                  helperText: 'Esperado: '
                      '${i.consumoTeorico(orden.superficieM2).toStringAsFixed(0)} ml '
                      '(deje 0 si no lo usó)',
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _guardando
                  ? null
                  : () => Navigator.pushNamed(context, '/impedimento', arguments: orden),
              child: const Text('Reportar impedimento'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: FilledButton(
              onPressed: foto == null || _guardando ? null : _finalizar,
              child: const Text('Finalizar rutina'),
            ),
          ),
        ]),
      ),
    );
  }
}
