import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/modelos/orden_trabajo.dart';
import '../data/repositorios/orden_repository.dart';
import '../servicios/sync_service.dart';

/// Reporte de un impedimento: la orden queda bloqueada y el supervisor decide (RF11).
class ImpedimentoScreen extends StatefulWidget {
  const ImpedimentoScreen({super.key, required this.orden});
  final OrdenTrabajo orden;

  @override
  State<ImpedimentoScreen> createState() => _ImpedimentoState();
}

class _ImpedimentoState extends State<ImpedimentoScreen> {
  static const _tipos = {
    'INSUMO': 'Falta un insumo',
    'EPP': 'Falta equipo de protección',
    'CLIMA': 'Clima (viento o lluvia)',
    'ACCESO': 'No hay acceso a la zona',
    'OTRO': 'Otro',
  };
  String _tipo = 'INSUMO';
  final _descripcion = TextEditingController();

  @override
  void dispose() {
    _descripcion.dispose();
    super.dispose();
  }

  Future<void> _enviar() async {
    final texto = _descripcion.text.trim();
    final repo = context.read<OrdenRepository>();
    final sync = context.read<SyncService>();
    final mensajes = ScaffoldMessenger.of(context);
    final navegador = Navigator.of(context);
    try {
      await repo.reportarImpedimento(
          widget.orden, _tipo, texto.isEmpty ? _tipos[_tipo]! : texto);
      sync.sincronizar();
      mensajes.showSnackBar(
          const SnackBar(content: Text('Impedimento registrado. La orden queda bloqueada.')));
      navegador.popUntil(ModalRoute.withName('/ordenes'));
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text('No se pudo registrar: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Impedimento · ${widget.orden.zonaNombre}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final entrada in _tipos.entries)
                ChoiceChip(
                  label: Text(entrada.value),
                  selected: _tipo == entrada.key,
                  onSelected: (_) => setState(() => _tipo = entrada.key),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descripcion,
            maxLines: 3,
            decoration: const InputDecoration(
                labelText: 'Detalle (opcional)', border: OutlineInputBorder()),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          width: double.infinity,
          child: FilledButton(onPressed: _enviar, child: const Text('Reportar y bloquear')),
        ),
      ),
    );
  }
}
