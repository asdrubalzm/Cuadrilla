import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/modelos/orden_trabajo.dart';
import '../data/repositorios/orden_repository.dart';

class ChecklistEppScreen extends StatefulWidget {
  const ChecklistEppScreen({super.key, required this.orden});
  final OrdenTrabajo orden;

  @override
  State<ChecklistEppScreen> createState() => _ChecklistEppState();
}

class _ChecklistEppState extends State<ChecklistEppScreen> {
  late final Map<String, bool> _items = {
    'Guantes y gafas de seguridad': false,
    'Químico y paños suficientes para la zona': false,
    'Señal de piso mojado colocada': false,
    if (widget.orden.requiereEppAltura) ...{
      'Escalera inspeccionada, sin defectos visibles': false,
      'Escalera sobre piso firme y área despejada': false,
    },
  };

  bool get _completo => _items.values.every((marcado) => marcado);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Seguridad · ${widget.orden.zonaNombre}')),
      body: ListView(children: [
        for (final item in _items.keys)
          CheckboxListTile(
            title: Text(item),
            value: _items[item],
            onChanged: (v) => setState(() => _items[item] = v ?? false),
          ),
      ]),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.pushNamed(context, '/impedimento',
                  arguments: widget.orden),
              child: const Text('Reportar faltante'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: FilledButton(
              onPressed: _completo ? _iniciar : null, // null deshabilita el botón
              child: const Text('Iniciar rutina'),
            ),
          ),
        ]),
      ),
    );
  }

  Future<void> _iniciar() async {
    await context.read<OrdenRepository>().iniciarOrden(widget.orden, _items);
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/ejecucion', arguments: widget.orden);
  }
}
