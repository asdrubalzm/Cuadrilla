import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/auth_storage.dart';
import '../data/repositorios/panel_repository.dart';
import 'revision_screen.dart';
import 'sprint_screen.dart';
import 'tablero_screen.dart';

/// Panel del supervisor y de la gerencia. Trabaja siempre en línea.
class PanelScreen extends StatefulWidget {
  const PanelScreen({super.key});

  @override
  State<PanelScreen> createState() => _PanelState();
}

class _PanelState extends State<PanelScreen> {
  List<Map<String, dynamic>> _sprints = [];
  String? _sprintId;
  String? _error;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    try {
      final sprints = await context.read<PanelRepository>().sprints();
      if (!mounted) return;
      setState(() {
        _sprints = sprints;
        _sprintId = sprints.isEmpty ? null : sprints.first['id'] as String;
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = mensajeDeError(e));
    }
  }

  Future<void> _salir() async {
    await context.read<AuthStorage>().cerrar();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final sesion = context.read<AuthStorage>().sesion;
    final sprintId = _sprintId;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Cuadrillas · ${sesion?.nombre ?? ''} (${sesion?.rol ?? ''})'),
          actions: [
            if (_sprints.length > 1)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: DropdownButton<String>(
                  value: sprintId,
                  underline: const SizedBox.shrink(),
                  items: [
                    for (final s in _sprints)
                      DropdownMenuItem(
                        value: s['id'] as String,
                        child: Text('Sprint ${s['fechaInicio']} a ${s['fechaFin']}'),
                      ),
                  ],
                  onChanged: (v) => setState(() => _sprintId = v),
                ),
              ),
            IconButton(onPressed: _salir, icon: const Icon(Icons.logout), tooltip: 'Salir'),
          ],
          bottom: const TabBar(tabs: [
            Tab(text: 'Sprint y asignación'),
            Tab(text: 'Revisión'),
            Tab(text: 'Tablero'),
          ]),
        ),
        body: _error != null
            ? Center(child: Text(_error!))
            : sprintId == null
                ? const Center(child: Text('No hay sprints registrados.'))
                : TabBarView(children: [
                    SprintScreen(key: ValueKey('s$sprintId'), sprintId: sprintId),
                    RevisionScreen(key: ValueKey('r$sprintId'), sprintId: sprintId),
                    TableroScreen(key: ValueKey('t$sprintId'), sprintId: sprintId),
                  ]),
      ),
    );
  }
}

/// Hora local corta a partir de una fecha ISO de la API.
String horaCorta(Object? iso) {
  if (iso == null) return '—';
  final f = DateTime.parse(iso as String).toLocal();
  return '${f.hour.toString().padLeft(2, '0')}:${f.minute.toString().padLeft(2, '0')}';
}
