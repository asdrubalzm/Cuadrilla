import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../data/repositorios/panel_repository.dart';
import 'panel_screen.dart';

/// Órdenes del sprint y asignación a operarios (RF05, RF06).
class SprintScreen extends StatefulWidget {
  const SprintScreen({super.key, required this.sprintId});
  final String sprintId;

  @override
  State<SprintScreen> createState() => _SprintState();
}

class _SprintState extends State<SprintScreen> {
  List<Map<String, dynamic>> _ordenes = [];
  List<Map<String, dynamic>> _operarios = [];
  bool _cargando = true;

  static const _asignables = {'PLANIFICADA', 'ASIGNADA', 'BLOQUEADA'};

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final panel = context.read<PanelRepository>();
    final mensajes = ScaffoldMessenger.of(context);
    try {
      final ordenes = await panel.ordenes(widget.sprintId);
      final operarios = await panel.operarios();
      if (!mounted) return;
      setState(() {
        _ordenes = ordenes;
        _operarios = operarios;
        _cargando = false;
      });
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text(mensajeDeError(e))));
      if (mounted) setState(() => _cargando = false);
    }
  }

  Future<void> _asignar(String ordenId, String operarioId) async {
    final panel = context.read<PanelRepository>();
    final mensajes = ScaffoldMessenger.of(context);
    try {
      await panel.asignar(ordenId, operarioId);
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text(mensajeDeError(e))));
    }
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) return const Center(child: CircularProgressIndicator());

    // Carga de cada operario: órdenes y superficie, para repartir con equilibrio
    final carga = <String, int>{};
    final superficie = <String, double>{};
    for (final o in _ordenes) {
      final id = o['operarioId'] as String?;
      if (id == null || o['estado'] == 'CANCELADA') continue;
      carga[id] = (carga[id] ?? 0) + 1;
      superficie[id] = (superficie[id] ?? 0) + (o['superficieM2'] as num).toDouble();
    }
    final sinAsignar = _ordenes.where((o) => o['estado'] == 'PLANIFICADA').length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          Chip(label: Text('${_ordenes.length} órdenes')),
          Chip(label: Text('$sinAsignar sin asignar')),
          for (final op in _operarios)
            Chip(
              label: Text('${op['nombre']}: ${carga[op['id']] ?? 0} órdenes, '
                  '${(superficie[op['id']] ?? 0).toStringAsFixed(0)} m²'),
            ),
          ActionChip(label: const Text('Actualizar'), onPressed: _cargar),
        ]),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Zona')),
              DataColumn(label: Text('Tipo')),
              DataColumn(label: Text('m²'), numeric: true),
              DataColumn(label: Text('Límite')),
              DataColumn(label: Text('Estado')),
              DataColumn(label: Text('Operario')),
            ],
            rows: [
              for (final o in _ordenes)
                DataRow(cells: [
                  DataCell(Text('${o['zonaNombre']}${o['requiereEppAltura'] == true ? ' (altura)' : ''}')),
                  DataCell(Text('${o['zonaTipo']}')),
                  DataCell(Text((o['superficieM2'] as num).toStringAsFixed(0))),
                  DataCell(Text(horaCorta(o['finPlan']))),
                  DataCell(Text('${o['estado']}'
                      '${o['nivelAlerta'] == 2 ? ' · vencida' : o['nivelAlerta'] == 1 ? ' · por vencer' : ''}')),
                  DataCell(_asignables.contains(o['estado'])
                      ? DropdownButton<String>(
                          value: o['operarioId'] as String?,
                          hint: const Text('Asignar…'),
                          underline: const SizedBox.shrink(),
                          items: [
                            for (final op in _operarios)
                              DropdownMenuItem(
                                  value: op['id'] as String, child: Text('${op['nombre']}')),
                          ],
                          onChanged: (v) {
                            if (v != null) _asignar(o['id'] as String, v);
                          },
                        )
                      : Text('${o['operarioNombre'] ?? '—'}')),
                ]),
            ],
          ),
        ),
      ],
    );
  }
}
