import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../data/repositorios/inventario_repository.dart';
import '../data/repositorios/panel_repository.dart';
import 'panel_screen.dart';

/// Estado del sprint, impedimentos, plazos, existencias y cumplimiento (RF14 a RF19).
class TableroScreen extends StatefulWidget {
  const TableroScreen({super.key, required this.sprintId});
  final String sprintId;

  @override
  State<TableroScreen> createState() => _TableroState();
}

class _TableroState extends State<TableroScreen> {
  Map<String, dynamic>? _tablero;
  Map<String, dynamic>? _sla;
  List<Map<String, dynamic>> _insumos = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final panel = context.read<PanelRepository>();
    final inventario = context.read<InventarioRepository>();
    try {
      final tablero = await panel.tablero(widget.sprintId);
      final sla = await panel.reporteSla();
      final insumos = await inventario.insumos();
      if (!mounted) return;
      setState(() {
        _tablero = tablero;
        _sla = sla;
        _insumos = insumos;
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = mensajeDeError(e));
    }
  }

  Future<void> _desbloquear(String ordenId) async {
    final panel = context.read<PanelRepository>();
    final mensajes = ScaffoldMessenger.of(context);
    try {
      await panel.desbloquear(ordenId);
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text(mensajeDeError(e))));
    }
    await _cargar();
  }

  Future<void> _ingresar(Map<String, dynamic> insumo) async {
    final cantidad = TextEditingController();
    final valor = await showDialog<double>(
      context: context,
      builder: (dialogo) => AlertDialog(
        title: Text('Ingreso de ${insumo['nombre']}'),
        content: TextField(
          controller: cantidad,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Cantidad (ml)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogo), child: const Text('Cancelar')),
          TextButton(
            onPressed: () => Navigator.pop(
                dialogo, double.tryParse(cantidad.text.replaceAll(',', '.'))),
            child: const Text('Registrar'),
          ),
        ],
      ),
    );
    if (valor == null || valor <= 0 || !mounted) return;

    final inventario = context.read<InventarioRepository>();
    final mensajes = ScaffoldMessenger.of(context);
    try {
      await inventario.registrarMovimiento(insumo['id'] as String, 'ENTRADA', valor);
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text(mensajeDeError(e))));
    }
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return Center(child: Text(_error!));
    final t = _tablero;
    final sla = _sla;
    if (t == null || sla == null) return const Center(child: CircularProgressIndicator());

    final titulo = Theme.of(context).textTheme.titleMedium;
    final evidencia = Map<String, dynamic>.from(sla['evidencia'] as Map);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(onPressed: _cargar, child: const Text('Actualizar')),
        ),
        Text('Órdenes por estado', style: titulo),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in t['porEstado'] as List)
            Chip(label: Text('${e['estado']}: ${e['total']}')),
        ]),
        const SizedBox(height: 20),
        Text('Carga por operario', style: titulo),
        for (final o in t['porOperario'] as List)
          ListTile(
            dense: true,
            title: Text('${o['operario']}'),
            subtitle: Text('${o['terminadas']} de ${o['asignadas']} terminadas · '
                '${(o['superficieM2'] as num).toStringAsFixed(0)} m²'),
          ),
        const SizedBox(height: 12),
        Text('Impedimentos abiertos', style: titulo),
        if ((t['bloqueadas'] as List).isEmpty) const Text('Ninguno.'),
        for (final b in t['bloqueadas'] as List)
          ListTile(
            leading: const Icon(Icons.block),
            title: Text('${b['zonaNombre']} · ${b['tipo']}'),
            subtitle: Text('${b['descripcion']} · reportado ${horaCorta(b['reportadoEn'])}'),
            trailing: TextButton(
                onPressed: () => _desbloquear(b['id'] as String),
                child: const Text('Marcar resuelto')),
          ),
        const SizedBox(height: 12),
        Text('Órdenes en riesgo frente al SLA', style: titulo),
        if ((t['enRiesgo'] as List).isEmpty) const Text('Ninguna.'),
        for (final r in t['enRiesgo'] as List)
          ListTile(
            leading: Icon(Icons.warning_amber,
                color: r['nivelAlerta'] == 2 ? Theme.of(context).colorScheme.error : null),
            title: Text('${r['zonaNombre']}'),
            subtitle: Text('Límite ${horaCorta(r['finPlan'])} · '
                '${r['nivelAlerta'] == 2 ? 'vencida' : 'por vencer'}'),
          ),
        const Divider(height: 32),
        Text('Existencias de insumos', style: titulo),
        for (final i in _insumos)
          ListTile(
            leading: Icon(i['bajoMinimo'] == true ? Icons.error_outline : Icons.inventory_2,
                color: i['bajoMinimo'] == true ? Theme.of(context).colorScheme.error : null),
            title: Text('${i['nombre']}'),
            subtitle: Text('${i['stockActual']} ${i['unidad']} en existencia · '
                'mínimo ${i['stockMinimo']} ${i['unidad']}'
                '${i['bajoMinimo'] == true ? ' · BAJO EL MÍNIMO' : ''}'),
            trailing: TextButton(
                onPressed: () => _ingresar(i), child: const Text('Registrar ingreso')),
          ),
        const Divider(height: 32),
        Text('Cumplimiento del SLA (últimos 30 días)', style: titulo),
        for (final c in sla['cumplimiento'] as List)
          ListTile(
            dense: true,
            title: Text('${c['edificio']}'),
            subtitle: Text('${c['aTiempo']} a tiempo de ${c['ejecutadas']} ejecutadas '
                '(${c['cumplimientoPct'] ?? '—'} %) · ${c['planificadas']} planificadas'),
          ),
        ListTile(
          dense: true,
          title: const Text('Órdenes con evidencia verificable'),
          subtitle: Text('${evidencia['conEvidenciaVerificable']} de '
              '${evidencia['ejecutadas']} ejecutadas'),
        ),
        for (final i in sla['insumos'] as List)
          ListTile(
            dense: true,
            title: Text('Consumo de ${i['nombre']}'),
            subtitle: Text('${i['real']} ml usados frente a ${i['teorico']} ml esperados '
                '(${i['desviacionPct'] ?? '—'} %) · costo USD ${i['costo']}'),
          ),
      ],
    );
  }
}
