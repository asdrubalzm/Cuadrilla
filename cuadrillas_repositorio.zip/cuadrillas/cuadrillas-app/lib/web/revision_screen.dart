import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../data/repositorios/panel_repository.dart';
import 'panel_screen.dart';

/// Revisión de evidencias y calificación de las órdenes terminadas (RF16).
class RevisionScreen extends StatefulWidget {
  const RevisionScreen({super.key, required this.sprintId});
  final String sprintId;

  @override
  State<RevisionScreen> createState() => _RevisionState();
}

class _RevisionState extends State<RevisionScreen> {
  List<Map<String, dynamic>> _ordenes = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final panel = context.read<PanelRepository>();
    final mensajes = ScaffoldMessenger.of(context);
    try {
      final ordenes = await panel.ordenes(widget.sprintId, estado: 'EN_REVISION');
      if (!mounted) return;
      setState(() {
        _ordenes = ordenes;
        _cargando = false;
      });
    } catch (e) {
      mensajes.showSnackBar(SnackBar(content: Text(mensajeDeError(e))));
      if (mounted) setState(() => _cargando = false);
    }
  }

  Future<void> _revisar(Map<String, dynamic> orden) async {
    await showDialog<void>(
      context: context,
      builder: (_) => _DialogoRevision(ordenId: orden['id'] as String),
    );
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) return const Center(child: CircularProgressIndicator());
    if (_ordenes.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('No hay órdenes en espera de revisión.'),
          TextButton(onPressed: _cargar, child: const Text('Actualizar')),
        ]),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(onPressed: _cargar, child: const Text('Actualizar')),
        ),
        for (final o in _ordenes)
          Card(
            child: ListTile(
              title: Text('${o['zonaNombre']} · ${o['operarioNombre'] ?? ''}'),
              subtitle: Text('Terminó ${horaCorta(o['finReal'])} · límite ${horaCorta(o['finPlan'])}'),
              trailing: FilledButton.tonal(
                  onPressed: () => _revisar(o), child: const Text('Revisar')),
            ),
          ),
      ],
    );
  }
}

class _DialogoRevision extends StatefulWidget {
  const _DialogoRevision({required this.ordenId});
  final String ordenId;

  @override
  State<_DialogoRevision> createState() => _DialogoRevisionState();
}

class _DialogoRevisionState extends State<_DialogoRevision> {
  Map<String, dynamic>? _detalle;
  final Map<String, Uint8List> _fotos = {};
  final _comentario = TextEditingController();
  int _puntaje = 5;
  String? _error;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  @override
  void dispose() {
    _comentario.dispose();
    super.dispose();
  }

  Future<void> _cargar() async {
    final panel = context.read<PanelRepository>();
    try {
      final detalle = await panel.detalle(widget.ordenId);
      if (!mounted) return;
      setState(() => _detalle = detalle);
      for (final e in detalle['evidencias'] as List) {
        if (e['archivoRecibido'] != true) continue;
        final bytes = await panel.fotografia(e['id'] as String);
        if (!mounted) return;
        setState(() => _fotos[e['id'] as String] = bytes);
      }
    } catch (e) {
      if (mounted) setState(() => _error = mensajeDeError(e));
    }
  }

  Future<void> _calificar(bool conforme) async {
    if (!conforme && _comentario.text.trim().isEmpty) {
      setState(() => _error = 'El rechazo requiere un comentario.'); // RN5
      return;
    }
    final panel = context.read<PanelRepository>();
    final navegador = Navigator.of(context);
    try {
      await panel.evaluar(widget.ordenId,
          conforme: conforme, puntaje: _puntaje, comentario: _comentario.text);
      navegador.pop();
    } catch (e) {
      if (mounted) setState(() => _error = mensajeDeError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _detalle;
    return AlertDialog(
      title: Text(d == null ? 'Cargando…' : '${d['zonaNombre']}'),
      content: SizedBox(
        width: 560,
        child: d == null
            ? (_error == null
                ? const SizedBox(height: 80, child: Center(child: CircularProgressIndicator()))
                : Text(_error!))
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Operario: ${d['operarioNombre'] ?? '—'}'),
                    Text('Inicio ${horaCorta(d['inicioReal'])} · fin ${horaCorta(d['finReal'])} · '
                        'límite ${horaCorta(d['finPlan'])} · '
                        '${d['cumpleSla'] == true ? 'dentro del SLA' : 'FUERA del SLA'}'),
                    const SizedBox(height: 12),
                    for (final e in d['evidencias'] as List) ...[
                      if (_fotos[e['id']] != null)
                        Image.memory(_fotos[e['id']]!, height: 260, fit: BoxFit.contain)
                      else
                        Text(e['archivoRecibido'] == true
                            ? 'Cargando fotografía…'
                            : 'La fotografía aún no llega al servidor.'),
                      Text(
                        '${e['tipo']} · ${e['capturadoEn']} · '
                        '${e['latitud'] == null ? 'sin ubicación' : '${e['latitud']}, ${e['longitud']}'}'
                        '${e['fueraDeGeocerca'] == true ? ' · FUERA DEL RADIO DEL EDIFICIO' : ''}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      Text('SHA-256 ${e['hashSha256']}',
                          style: Theme.of(context).textTheme.bodySmall),
                      const SizedBox(height: 8),
                    ],
                    if (d['checklist'] != null)
                      Text('Lista de seguridad: '
                          '${(d['checklist']['items'] as Map).keys.join(', ')}'),
                    const SizedBox(height: 8),
                    for (final c in d['consumos'] as List)
                      Text('${c['nombre']}: ${c['real']} ml usados '
                          '(esperado ${c['teorica']} ml)'),
                    const Divider(height: 24),
                    Row(children: [
                      const Text('Puntaje: '),
                      for (var p = 1; p <= 5; p++)
                        Padding(
                          padding: const EdgeInsets.only(right: 4),
                          child: ChoiceChip(
                            label: Text('$p'),
                            selected: _puntaje == p,
                            onSelected: (_) => setState(() => _puntaje = p),
                          ),
                        ),
                    ]),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _comentario,
                      maxLines: 2,
                      decoration: const InputDecoration(
                          labelText: 'Comentario (obligatorio si rechaza)',
                          border: OutlineInputBorder()),
                    ),
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(_error!,
                            style: TextStyle(color: Theme.of(context).colorScheme.error)),
                      ),
                  ],
                ),
              ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
        if (d != null) ...[
          OutlinedButton(onPressed: () => _calificar(false), child: const Text('Rechazar')),
          FilledButton(onPressed: () => _calificar(true), child: const Text('Aprobar')),
        ],
      ],
    );
  }
}
