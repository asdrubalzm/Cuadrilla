import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/api_client.dart';
import 'core/auth_storage.dart';
import 'core/rutas.dart';
import 'data/repositorios/inventario_repository.dart';
import 'data/repositorios/orden_repository.dart';
import 'data/repositorios/panel_repository.dart';
import 'servicios/evidencia_service.dart';
import 'servicios/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final auth = AuthStorage();
  await auth.cargar();
  final api = crearCliente(auth);
  final sync = SyncService(api);
  // En el teléfono, cada vez que vuelve la red se vacía la cola de operaciones.
  if (!kIsWeb) sync.escucharRed();

  runApp(MultiProvider(
    providers: [
      Provider<AuthStorage>.value(value: auth),
      Provider<Dio>.value(value: api),
      Provider<SyncService>.value(value: sync),
      Provider<OrdenRepository>(create: (_) => OrdenRepository(api)),
      Provider<EvidenciaService>(create: (_) => EvidenciaService()),
      Provider<PanelRepository>(create: (_) => PanelRepository(api)),
      Provider<InventarioRepository>(create: (_) => InventarioRepository(api)),
    ],
    child: CuadrillasApp(rutaInicial: rutaInicial(auth.sesion)),
  ));
}

class CuadrillasApp extends StatelessWidget {
  const CuadrillasApp({super.key, required this.rutaInicial});
  final String rutaInicial;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cuadrillas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1F3A5F),
        useMaterial3: true,
        // Botones altos: la aplicación se usa con guantes (RNF06)
        filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(minimumSize: const Size(64, 56))),
        outlinedButtonTheme: OutlinedButtonThemeData(
            style: OutlinedButton.styleFrom(minimumSize: const Size(64, 56))),
      ),
      initialRoute: rutaInicial,
      onGenerateRoute: generarRuta,
      // Una sola pantalla en la pila al arrancar (sin la ruta '/' por debajo)
      onGenerateInitialRoutes: (ruta) => [generarRuta(RouteSettings(name: ruta))],
    );
  }
}
