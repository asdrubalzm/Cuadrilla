import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/api_client.dart';
import '../core/auth_storage.dart';
import '../core/rutas.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginState();
}

class _LoginState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _clave = TextEditingController();
  bool _enviando = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _clave.dispose();
    super.dispose();
  }

  Future<void> _entrar() async {
    setState(() {
      _enviando = true;
      _error = null;
    });
    final auth = context.read<AuthStorage>();
    try {
      final resp = await context.read<Dio>().post('/auth/login',
          data: {'email': _email.text.trim(), 'clave': _clave.text});
      final usuario = Map<String, dynamic>.from(resp.data['usuario'] as Map);
      final sesion = Sesion(
        token: resp.data['token'] as String,
        usuarioId: usuario['id'] as String,
        nombre: usuario['nombre'] as String,
        rol: usuario['rol'] as String,
      );
      await auth.guardar(sesion);
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, rutaInicial(sesion));
    } catch (e) {
      if (mounted) setState(() => _error = mensajeDeError(e));
    } finally {
      if (mounted) setState(() => _enviando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.all(24),
            children: [
              Text('Cuadrillas', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 4),
              const Text('Control de rutinas de limpieza de vidrios'),
              const SizedBox(height: 24),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                decoration: const InputDecoration(
                    labelText: 'Correo', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _clave,
                obscureText: true,
                onSubmitted: (_) => _entrar(),
                decoration: const InputDecoration(
                    labelText: 'Contraseña', border: OutlineInputBorder()),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _enviando ? null : _entrar,
                child: Text(_enviando ? 'Ingresando…' : 'Ingresar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
