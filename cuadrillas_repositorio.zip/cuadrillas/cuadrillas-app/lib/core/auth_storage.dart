import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

class Sesion {
  const Sesion({
    required this.token,
    required this.usuarioId,
    required this.nombre,
    required this.rol,
  });
  final String token;
  final String usuarioId;
  final String nombre;
  final String rol; // OPERARIO, SUPERVISOR o GERENTE

  bool get esOperario => rol == 'OPERARIO';
}

/// Guarda el token en el almacén seguro del sistema operativo.
class AuthStorage {
  final _caja = const FlutterSecureStorage();
  Sesion? _sesion;
  String _dispositivoId = 'desconocido';

  Sesion? get sesion => _sesion;
  String get dispositivoId => _dispositivoId;

  Future<void> cargar() async {
    var id = await _caja.read(key: 'dispositivo_id');
    if (id == null) {
      id = const Uuid().v4();
      await _caja.write(key: 'dispositivo_id', value: id);
    }
    _dispositivoId = id;

    final token = await _caja.read(key: 'token');
    if (token == null) return;
    _sesion = Sesion(
      token: token,
      usuarioId: await _caja.read(key: 'usuario_id') ?? '',
      nombre: await _caja.read(key: 'nombre') ?? '',
      rol: await _caja.read(key: 'rol') ?? '',
    );
  }

  Future<void> guardar(Sesion s) async {
    _sesion = s;
    await _caja.write(key: 'token', value: s.token);
    await _caja.write(key: 'usuario_id', value: s.usuarioId);
    await _caja.write(key: 'nombre', value: s.nombre);
    await _caja.write(key: 'rol', value: s.rol);
  }

  Future<void> cerrar() async {
    _sesion = null;
    for (final clave in ['token', 'usuario_id', 'nombre', 'rol']) {
      await _caja.delete(key: clave);
    }
  }
}
