import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';

import '../data/modelos/orden_trabajo.dart';
import '../movil/checklist_epp_screen.dart';
import '../movil/ejecucion_screen.dart';
import '../movil/impedimento_screen.dart';
import '../movil/ordenes_screen.dart';
import '../pantallas/login_screen.dart';
import '../web/panel_screen.dart';
import 'auth_storage.dart';

/// Pantalla de entrada según la sesión guardada y el rol.
String rutaInicial(Sesion? sesion) {
  if (sesion == null) return '/login';
  return sesion.esOperario ? '/ordenes' : '/panel';
}

Route<dynamic> generarRuta(RouteSettings ajustes) {
  Widget pantalla;
  switch (ajustes.name) {
    case '/ordenes':
      // El operario necesita la base local, que no existe en el navegador
      pantalla = kIsWeb ? const _SoloTelefono() : const OrdenesScreen();
    case '/checklist':
      pantalla = ChecklistEppScreen(orden: ajustes.arguments as OrdenTrabajo);
    case '/ejecucion':
      pantalla = EjecucionScreen(orden: ajustes.arguments as OrdenTrabajo);
    case '/impedimento':
      pantalla = ImpedimentoScreen(orden: ajustes.arguments as OrdenTrabajo);
    case '/panel':
      pantalla = const PanelScreen();
    default:
      pantalla = const LoginScreen();
  }
  return MaterialPageRoute(builder: (_) => pantalla, settings: ajustes);
}

class _SoloTelefono extends StatelessWidget {
  const _SoloTelefono();

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'La cuenta de operario se usa desde la aplicación del teléfono.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
}
