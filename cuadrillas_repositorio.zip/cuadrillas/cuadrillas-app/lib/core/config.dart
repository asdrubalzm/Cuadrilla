class Config {
  /// Dirección de la API. Se fija al compilar:
  ///   flutter run --dart-define=API_URL=http://192.168.1.50:3000
  /// El valor por defecto apunta al equipo anfitrión visto desde el emulador de Android.
  static const apiUrl =
      String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:3000');
}
