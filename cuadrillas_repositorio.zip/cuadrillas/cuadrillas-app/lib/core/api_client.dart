import 'package:dio/dio.dart';

import 'auth_storage.dart';
import 'config.dart';

/// Cliente HTTP único de la aplicación. El interceptor añade el token JWT
/// y el identificador del dispositivo a cada petición.
Dio crearCliente(AuthStorage auth) {
  final dio = Dio(BaseOptions(
    baseUrl: Config.apiUrl,
    connectTimeout: const Duration(seconds: 8),
    receiveTimeout: const Duration(seconds: 20),
  ));
  dio.interceptors.add(InterceptorsWrapper(
    onRequest: (opciones, handler) {
      final token = auth.sesion?.token;
      if (token != null) opciones.headers['Authorization'] = 'Bearer $token';
      opciones.headers['X-Dispositivo'] = auth.dispositivoId;
      handler.next(opciones);
    },
  ));
  return dio;
}

/// Mensaje legible a partir de un error de red o de la API.
String mensajeDeError(Object error) {
  if (error is DioException) {
    final datos = error.response?.data;
    if (datos is Map && datos['message'] != null) {
      final m = datos['message'];
      return m is List ? m.join('. ') : m.toString();
    }
    if (error.response == null) return 'Sin conexión con el servidor';
    return 'Error ${error.response?.statusCode}';
  }
  return error.toString();
}
