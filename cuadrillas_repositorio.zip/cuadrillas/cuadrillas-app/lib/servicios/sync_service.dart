import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:sqflite/sqflite.dart';

import '../data/local_db.dart';

class SyncService {
  SyncService(this._api);
  final Dio _api;        // cliente HTTP; un interceptor añade el token JWT
  bool _enCurso = false;

  void escucharRed() {
    Connectivity().onConnectivityChanged.listen((estados) {
      if (!estados.contains(ConnectivityResult.none)) sincronizar();
    });
  }

  Future<void> sincronizar() async {
    if (_enCurso) return; // evita dos envíos simultáneos
    _enCurso = true;
    final db = await LocalDb.instancia;
    try {
      final pendientes = await db.query('cola_sync',
          where: "estado = 'PENDIENTE' AND intentos < 8",
          orderBy: 'creado_en',
          limit: 25);

      if (pendientes.isNotEmpty) {
        final resp = await _api.post('/sync/lote', data: {
          'operaciones': [
            for (final op in pendientes)
              {
                'operacionUuid': op['operacion_uuid'],
                'entidad': op['entidad'],
                'accion': op['accion'],
                'payload': jsonDecode(op['payload'] as String),
              }
          ]
        });

        for (final r in resp.data['resultados'] as List) {
          final aceptada = r['estado'] == 'APLICADA' || r['estado'] == 'DUPLICADA';
          await db.update(
            'cola_sync',
            {
              'estado': aceptada ? 'ENVIADA' : 'RECHAZADA',
              'ultimo_error': r['detalle'],
            },
            where: 'operacion_uuid = ?',
            whereArgs: [r['operacionUuid']],
          );
        }
      }
      await _subirEvidencias(db); // las fotografías viajan al final, una por petición
    } on DioException catch (e) {
      // Sin red o servidor caído: las operaciones quedan para el siguiente intento
      await db.rawUpdate(
          "UPDATE cola_sync SET intentos = intentos + 1, ultimo_error = ? "
          "WHERE estado = 'PENDIENTE'",
          [e.message]);
    } finally {
      _enCurso = false;
    }
  }

  /// Sube las fotografías cuyos metadatos ya llegaron al servidor con el cierre de la orden.
  Future<void> _subirEvidencias(Database db) async {
    final fotos = await db.query('evidencia', where: 'subida = 0', limit: 10);
    for (final foto in fotos) {
      try {
        await _api.post('/evidencias',
            data: FormData.fromMap({
              'evidenciaId': foto['id'],
              'archivo': await MultipartFile.fromFile(foto['ruta'] as String,
                  filename: '${foto['id']}.jpg'),
            }));
        await db.update('evidencia', {'subida': 1},
            where: 'id = ?', whereArgs: [foto['id']]);
      } on DioException catch (e) {
        final codigo = e.response?.statusCode;
        if (codigo == 404) continue; // la orden todavía no llegó al servidor
        if (codigo == 403 || codigo == 422) {
          // evidencia ajena o archivo que no coincide con su huella: no se reintenta
          await db.update('evidencia', {'subida': 2},
              where: 'id = ?', whereArgs: [foto['id']]);
          continue;
        }
        rethrow; // sin red: se reintenta en la próxima sincronización
      }
    }
  }
}
