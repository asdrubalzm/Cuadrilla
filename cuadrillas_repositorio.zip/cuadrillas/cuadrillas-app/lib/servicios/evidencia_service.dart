import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../data/modelos/evidencia.dart';

class EvidenciaService {
  final _picker = ImagePicker();

  Future<Evidencia?> capturar(String ordenId, String tipo) async {
    // Solo cámara: no se ofrece la galería (RF10)
    final XFile? foto = await _picker.pickImage(
        source: ImageSource.camera, imageQuality: 70, maxWidth: 1600);
    if (foto == null) return null; // el operario canceló

    Position? pos;
    try {
      await _asegurarPermiso();
      pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 10)));
    } catch (_) {
      pos = await _ultimaConocida(); // interiores y subsuelos
    }

    final bytes = await File(foto.path).readAsBytes();
    return Evidencia(
      id: const Uuid().v4(),
      ordenId: ordenId,
      tipo: tipo, // 'ANTES' o 'DESPUES'
      ruta: foto.path,
      hashSha256: sha256.convert(bytes).toString(),
      latitud: pos?.latitude,
      longitud: pos?.longitude,
      precisionM: pos?.accuracy,
      capturadoEn: DateTime.now().toUtc(),
    );
  }

  /// La ubicación se pide solo al capturar una evidencia, nunca de forma continua (RNF10).
  Future<void> _asegurarPermiso() async {
    var permiso = await Geolocator.checkPermission();
    if (permiso == LocationPermission.denied) {
      permiso = await Geolocator.requestPermission();
    }
    if (permiso == LocationPermission.denied ||
        permiso == LocationPermission.deniedForever) {
      throw StateError('Sin permiso de ubicación');
    }
  }

  Future<Position?> _ultimaConocida() async {
    try {
      return await Geolocator.getLastKnownPosition();
    } catch (_) {
      return null; // sin permiso o sin posición previa: la evidencia se marca para revisión
    }
  }
}
