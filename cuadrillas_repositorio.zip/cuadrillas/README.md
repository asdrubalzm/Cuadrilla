# Cuadrillas: gestión operativa de cuadrillas de limpieza de vidrios (prototipo)

Prototipo académico del trabajo de titulación de Jorge Asdrúbal Zambrano Mendoza
(Ingeniería en Tecnologías de la Información, Universidad Estatal de Milagro).

Combina prácticas del PMBOK (alcance, costos, riesgos, calidad frente al SLA) con Scrum
(sprints, pila de trabajo, impedimentos) en un producto de tres partes:

| Carpeta | Qué es | Tecnología |
|---|---|---|
| `cuadrillas-api/` | API REST, reglas de negocio y base de datos | NestJS 11, TypeORM, PostgreSQL 16 |
| `cuadrillas-app/` | Aplicación móvil del operario (funciona sin conexión) y panel web del supervisor | Flutter, SQLite |
| `docs/` | Escenario simulado, guía de pruebas y hoja de resultados | Markdown |

> **Datos simulados.** El edificio, el cliente, las personas, las superficies y los costos de
> `migrations/002_datos_simulados.sql` son ficticios y se crearon para validar el prototipo en un
> entorno controlado. No provienen de ninguna empresa ni representan su operación.

## Requisitos

- Docker Desktop (o Docker Engine con Compose)
- Node.js 22 o superior
- Flutter 3.22 o superior (Dart 3.4 o superior), con un emulador o un teléfono Android 8.0+
- Git

## 1. Levantar la API y la base de datos

```bash
cd cuadrillas-api
docker compose up --build
```

La primera vez, PostgreSQL crea el esquema (16 tablas) y carga el escenario simulado.
Comprobación rápida desde otra terminal:

```bash
curl -s -X POST http://localhost:3000/auth/login \
  -H "content-type: application/json" \
  -d '{"email":"supervisor@demo.local","clave":"Demo2026*"}'
```

Debe responder un objeto con `token` y `usuario`. Para volver al estado inicial:
`docker compose down -v && docker compose up`.

**Sin Docker:** cree una base PostgreSQL 16 llamada `cuadrillas`, ejecute en orden los dos
archivos de `migrations/` con `psql`, copie `.env.example` como `.env` y ejecute
`npm install && npm run start:dev`.

### Cuentas de demostración (contraseña `Demo2026*`)

| Rol | Correo |
|---|---|
| Gerente | `gerente@demo.local` |
| Supervisor | `supervisor@demo.local` |
| Operarios | `ana@`, `luis@`, `marta@demo.local` |

## 2. Pruebas del servidor

```bash
cd cuadrillas-api
npm install
npm test                 # 32 pruebas unitarias del dominio (no necesitan base de datos)
docker compose exec -T db psql -U cuadrillas -d cuadrillas -v ON_ERROR_STOP=1 < test/esquema.sql
                         # 10 comprobaciones de las reglas que impone la base
npm run test:flujo       # recorrido de la API: CP01, CP02, CP03, CP06, CP08, CP10, CP11, CP12
npm run test:carga       # CP14: 50 usuarios simulados durante 5 minutos
```

`test:flujo` modifica datos: reinicie la base antes de las pruebas manuales.

## 3. Aplicación móvil y panel web

Las carpetas de plataforma (`android/`, `web/`) no se versionan aquí; se generan una vez:

```bash
cd cuadrillas-app
flutter create . --platforms=android,web --project-name cuadrillas_app
rm test/widget_test.dart          # prueba de ejemplo que genera Flutter; no aplica
flutter pub get
flutter test                      # pruebas unitarias del cliente
```

En `android/app/src/main/AndroidManifest.xml` añada, antes de `<application`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

y, dentro de la etiqueta `<application ...>`, el atributo `android:usesCleartextTraffic="true"`
(la API local usa HTTP; en producción debe usarse HTTPS y quitar este atributo).

Ejecutar:

```bash
# Emulador de Android (10.0.2.2 es el equipo anfitrión visto desde el emulador)
flutter run --dart-define=API_URL=http://10.0.2.2:3000

# Teléfono real en la misma red wifi que el computador (use la IP del computador)
flutter run --dart-define=API_URL=http://192.168.1.50:3000

# Panel web del supervisor
flutter run -d chrome --dart-define=API_URL=http://localhost:3000
```

Con una cuenta de operario se abre la aplicación de campo; con la de supervisor o gerente, el panel.

## 4. Qué se comprobó y qué falta comprobar

- **Ejecutado al preparar el código:** las 32 pruebas unitarias del dominio (Node.js 22), el
  esquema y el escenario sobre PostgreSQL 16, las 10 comprobaciones de `test/esquema.sql` y la
  validez de todas las consultas SQL de los servicios contra ese esquema.
- **Pendiente en su equipo:** compilar y ejecutar la API de NestJS y la aplicación de Flutter.
  El código se escribió sin poder instalar esas dependencias, así que el primer `npm run build`
  o `flutter run` puede señalar ajustes menores (por ejemplo, por una versión más reciente de
  una biblioteca). Corríjalos y registre el cambio en el historial de Git.
- Los casos de aceptación en el teléfono (modo avión, cámara, GPS) se ejecutan a mano siguiendo
  `docs/GUIA_DE_PRUEBAS.md`.

## 5. Subir a GitHub

El documento describe dos repositorios, uno por cada lado de la arquitectura:

```bash
cd cuadrillas-api && git init && git add . && git commit -m "API del prototipo de cuadrillas"
git branch -M main && git remote add origin https://github.com/<usuario>/cuadrillas-api.git && git push -u origin main

cd ../cuadrillas-app && git init && git add . && git commit -m "Aplicación móvil y panel web"
git branch -M main && git remote add origin https://github.com/<usuario>/cuadrillas-app.git && git push -u origin main
```

Si prefiere un solo repositorio, ejecute `git init` en esta carpeta raíz.

## Principales rutas de la API

| Método y ruta | Rol | Función |
|---|---|---|
| `POST /auth/login` | Todos | Valida credenciales y entrega el token |
| `GET /sprints`, `POST /sprints` | Supervisor | Consulta y crea sprints |
| `POST /ordenes`, `GET /ordenes` | Supervisor | Crea y lista órdenes |
| `POST /ordenes/:id/asignar` | Supervisor | Asigna o reasigna una orden |
| `GET /ordenes/mias` | Operario | Órdenes abiertas e insumos para guardar en el teléfono |
| `POST /sync/lote` | Operario | Recibe operaciones hechas sin conexión (idempotente) |
| `POST /evidencias` | Operario | Recibe una fotografía y verifica su huella SHA-256 |
| `POST /ordenes/:id/evaluacion` | Supervisor | Aprueba o rechaza una orden en revisión |
| `POST /ordenes/:id/desbloqueo` | Supervisor | Resuelve un impedimento |
| `GET /inventario/insumos`, `POST /inventario/movimientos` | Supervisor, gerente | Existencias e ingresos |
| `GET /tablero/sprints/:id` | Supervisor, gerente | Estado del sprint |
| `GET /reportes/sla` | Gerente, supervisor | Cumplimiento, evidencia verificable y costo de insumos |
